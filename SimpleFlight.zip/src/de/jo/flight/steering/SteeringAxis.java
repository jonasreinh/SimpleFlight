/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.flight.steering;

import com.jme3.math.FastMath;

/**
 *
 * @author jonas.reinhardt
 */
public class SteeringAxis {

    public enum AxisMode {

        Static, MoveToTarget
    }

    public enum DirectionBehaviour {

        SimpleSum, FitToSign
    }
    private AxisMode mode;
    private DirectionBehaviour directionBehaviour = DirectionBehaviour.SimpleSum;
    private float minValue;
    private float maxValue;
    private float targetValue;
    private float currentValue;
    private long lastInputTime;
    private long timeWait = 100;
    private boolean sleeping = true;
    private float accelerationPerMs = 0.00001f;

    public SteeringAxis(AxisMode mode, float minValue, float maxValue) {
        this.mode = mode;
        this.minValue = minValue;
        this.maxValue = maxValue;
    }

    public SteeringAxis(AxisMode mode, float minValue, float maxValue, float targetValue) {
        this.mode = mode;
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.targetValue = targetValue;
    }

    public void onInput(float value) {
        this.lastInputTime = System.currentTimeMillis();

        if (FastMath.sign(currentValue) == FastMath.sign(value)) {
            currentValue += value;
        } else {

            switch (directionBehaviour) {
                case SimpleSum:
                    currentValue += value;
                    break;

                case FitToSign:

                    currentValue = value;
                    break;
                    
            }
        }


        currentValue = currentValue < minValue ? minValue : currentValue;
        currentValue = currentValue > maxValue ? maxValue : currentValue;

        sleeping = false;
    }

    public void update(long currentTime) {
        if (!sleeping) {
            long timeOverWait = currentTime - (this.lastInputTime + timeWait);




            switch (mode) {

                case MoveToTarget:


                    if (timeOverWait > 0) {



                        float sign = Math.signum(targetValue - currentValue);

                        //System.out.println("timeOverWait: " + timeOverWait + "  timeOverWait * accelerationPerMs *sign: " + (timeOverWait * accelerationPerMs * sign) + " currentValue: " + currentValue);


                        float newValue = currentValue + timeOverWait * timeOverWait * accelerationPerMs * sign;

                        if (Math.signum(targetValue - newValue) != sign) {

                            newValue = targetValue;
                            sleeping = true;
                        }

                        currentValue = newValue;

                    }


                    break;
            }
        }

    }

    public DirectionBehaviour getDirectionBehaviour() {
        return directionBehaviour;
    }

    public void setDirectionBehaviour(DirectionBehaviour directionBehaviour) {
        this.directionBehaviour = directionBehaviour;
    }

    private boolean isTargetValue() {
        return currentValue == targetValue;
    }

    public AxisMode getMode() {
        return mode;
    }

    public float getMinValue() {
        return minValue;
    }

    public float getMaxValue() {
        return maxValue;
    }

    public float getTargetValue() {
        return targetValue;
    }

    public float getValue() {
        return currentValue;
    }

    public float getNormalizedValue() {
        return currentValue / (maxValue - minValue);
    }

    public long getLastInputTime() {
        return lastInputTime;
    }

    public long getTimeWait() {
        return timeWait;
    }

    public float getAccelerationPerMs() {
        return accelerationPerMs;
    }

    public void setMode(AxisMode mode) {
        this.mode = mode;
    }

    public void setMinValue(float minValue) {
        this.minValue = minValue;
    }

    public void setMaxValue(float maxValue) {
        this.maxValue = maxValue;
    }

    public void setTargetValue(float targetValue) {
        this.targetValue = targetValue;
    }

    public void setTimeWait(long timeWait) {
        this.timeWait = timeWait;
    }

    public void setAccelerationPerMs(float accelerationPerMs) {
        this.accelerationPerMs = accelerationPerMs;
    }
}
