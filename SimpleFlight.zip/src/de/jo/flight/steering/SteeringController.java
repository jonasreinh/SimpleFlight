/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.flight.steering;

import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.Vector3f;
import de.jo.gui.AxisViewController;
import mygame.FlyApp;

/**
 *
 * @author jonas.reinhardt
 */
public class SteeringController {

    private AxisViewController guiController;
    private FlightSteering flightSteering;
    private FlightControl flightControl;

    public SteeringController(AxisViewController guiController) {
        this.guiController = guiController;
        flightSteering = new FlightSteering();
    }

    public FlightControl getRigidBody() {
        return flightControl;
    }

    public void setFlightControl(FlightControl flightControl) {
        this.flightControl = flightControl;
    }

    public void update() {
        long time = System.currentTimeMillis();

        flightSteering.update(time);
        
        
        
        
        if (flightControl != null) {
            flightControl.roll = flightSteering.rollAxis.getNormalizedValue()*0.1f;
         flightControl.pitch = flightSteering.pitchAxis.getNormalizedValue()*0.1f;
         flightControl.yaw = flightSteering.yawAxis.getNormalizedValue()*0.1f;
         flightControl.throttle = flightSteering.forwardThrottleAxis.getNormalizedValue()*0.1f;
        }

        if(this.guiController.getFlightCursor()!=null){
        this.guiController.getFlightCursor().updateAxisDisplay(flightSteering.rollAxis.getValue(), flightSteering.pitchAxis.getValue(),flightSteering.yawAxis.getValue(),flightSteering.forwardThrottleAxis.getValue());
        }

    }

    public FlightControl getFlightControl() {
        return flightControl;
    }
    
    
}
