/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.flight.steering;

import com.jme3.bullet.PhysicsSpace;
import com.jme3.bullet.PhysicsTickListener;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.FastMath;
import com.jme3.math.Matrix3f;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;

/**
 *
 * @author jonas.reinhardt
 */
public class FlightControl extends RigidBodyControl implements PhysicsTickListener{
    
    public float roll;
    public float pitch;
    public float yaw;
    
    public float throttle;
    private Matrix3f rotation = new Matrix3f();
    private Vector3f velocity = new Vector3f();
    private Vector3f angles  = new Vector3f();
    private Vector2f attackAngles  = new Vector2f();
    
    private Vector3f localVel = new Vector3f();
    private Vector3f localVelOri = new Vector3f();
    //private Vector3f linearVelocity; 
    
    
    public void prePhysicsTick(PhysicsSpace space, float tpf) {
      // System.out.println("prePhysicsTick "); //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.getPhysicsRotationMatrix(rotation);
        
        
        this.getLinearVelocity(velocity);
        
         rotation.invert().mult(velocity, localVel);
         //localVel;;.normalizeLocal();
         localVelOri = localVel.normalize();
         angles = rotation.invert().mult(velocity.normalize());
        
         
         attackAngles.x =  (float)Math.atan2(localVel.x, localVel.y);//= new Vector2f(getBeta(angles.x,angles.y),(FastMath.acos(angles.z)*360)/(2*FastMath.PI));//new Vector2f(FastMath.acos(angles.z)*(360/(2*FastMath.PI)),(FastMath.asin(angles.y)*(360/(2*FastMath.PI))));
        
        //System.out.println("angle: ("+attackAngles+") z: "+angles.z);//attackAngles.x+","+attackAngles.y
        
        this.applyTorqueImpulse(rotation.mult(new Vector3f(50*pitch,-50*yaw,50*roll)));
        this.applyImpulse(rotation.mult(new Vector3f(0, 0, 50*throttle)), rotation.mult(new Vector3f(0, 0, -2)));
        this.applyImpulse(rotation.mult(new Vector3f(-0.3f*localVel.x, -0.95f*localVel.y, -0.001f*Math.signum(localVel.z)*localVel.z*localVel.z)), Vector3f.ZERO);
    
    }

    public Vector3f getVelocity() {
        return velocity;
    }

    public Vector3f getAngles() {
        return angles;
    }

    public Vector2f getAttackAngles() {
        return attackAngles;
    }

    public Vector3f getLocalVel() {
        return localVel;
    }

    public Vector3f getLocalVelOri() {
        return localVelOri;
    }

    
    
    
    
    private static float getBeta(float x, float y){
	//float atan = 
	boolean xNeg = x<0;
return 180*((x==0) ? (y==0? 0 : y<0? 0:1) :( (xNeg ? 1 : 0)+0.5f+(FastMath.atan(((y)/(x)))/(FastMath.PI))));
	
	
}
    
    public void physicsTick(PhysicsSpace space, float tpf) {
       // System.out.println("physicsTick ");//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //this.getL
    }

    public FlightControl(float mass) {
        super(mass);
    }

    
    
}
