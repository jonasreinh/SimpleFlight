/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.asset.AssetManager;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.FastMath;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Mesh;
import de.jo.mesh.dynamic.DynamicGeometry;
import java.util.Comparator;
import java.util.Random;
import java.util.TreeSet;

/**
 *
 * @author jonas.reinhardt
 */
public class SphericData {

   
    private DynamicGeometry dataDisplay;
    private TreeSet<VertexPoint> pointsX = new TreeSet<VertexPoint>(new PointXComparator());
    private TreeSet<VertexPoint> pointsY = new TreeSet<VertexPoint>(new PointYComparator());
    private TreeSet<VertexPoint> pointsZ = new TreeSet<VertexPoint>(new PointZComparator());

    public SphericData() {
  


       


       

    }
    
    
    public void init(AssetManager am,Material mat){
        
        dataDisplay = new DynamicGeometry();
        dataDisplay.init(am, mat);
        dataDisplay.getMaterial().setColor("Color", ColorRGBA.White);
        dataDisplay.getDynamicMesh().setUseColor(true);

        dataDisplay.getDynamicMesh().setMode(Mesh.Mode.Points);
        
        //dataDisplay.getDynamicMesh().setPointSize(8);

        int longi = 6;

        int lati = 8;

        Quaternion rotQz = new Quaternion(new float[]{0, 0, (2 * FastMath.PI) / (lati - 1)});
        Quaternion rotQx = new Quaternion(new float[]{0.2f, 0, longi});
        Quaternion rot = new Quaternion();
        //for (int longi = 0; longi < longitude; longi++) {
        Vector3f vec = new Vector3f(0, 0, 1);
        Vector3f[] pointPositions = new Vector3f[longi * lati];
        ColorRGBA[] pointColors = new ColorRGBA[longi * lati];
        Random rand = new Random();
        int i = 0;
        for (int rotx = 0; rotx < longi; rotx++) {

            for (int rotz = 0; rotz < lati; rotz++) {
                rot.fromAngles(new float[]{0.2f * rotx, 0, rotz * ((2 * FastMath.PI) / (lati))});
                pointPositions[i] = rot.mult(Vector3f.UNIT_Z);//vec.clone();
                //vec = rotQz.mult(vec).normalize();

                VertexPoint p = new VertexPoint(i, pointPositions[i].clone());
                pointColors[i] = new ColorRGBA(rand.nextFloat(), rand.nextFloat(), rand.nextFloat(), 1);

                pointsX.add(p);
                pointsY.add(p);
                pointsZ.add(p);

                i++;
            }
            //vec = rotQx.mult(vec).normalize();
        }

        dataDisplay.getDynamicMesh().addIndexes(longi * lati);

        dataDisplay.getDynamicMesh().addColors(longi * lati);
        dataDisplay.getDynamicMesh().addVertexes(longi * lati);
        //dataDisplay.getDynamicMesh().addColors(latitude);
        dataDisplay.getDynamicMesh().updateMesh();
        // }

        dataDisplay.getDynamicMesh().setVertexPositionData(0, pointPositions);

        dataDisplay.getDynamicMesh().setVertexColorData(0, pointColors);

        dataDisplay.getMaterial().setBoolean("VertexColor", true);
        dataDisplay.getDynamicMesh().applyBuffers();
        
        dataDisplay.setLocalTranslation(1, 1, 1);
        
        dataDisplay.updateModelBound();
        dataDisplay.updateGeometricState();
    }

    /*public void updatePosition(Vector3f pos) {
    dataDisplay.setLocalTranslation(pos);
    }*/
    public DynamicGeometry getDataDisplay() {
        return dataDisplay;
    }
    
    
    
    
    public void updatePosition(Vector3f pos) {
        dataDisplay.setLocalTranslation(pos);
        
    }

    public class PointXComparator implements Comparator<VertexPoint> {

        public int compare(VertexPoint o1, VertexPoint o2) {
            return (int) ((2 << 24) * (o1.getPosition().x - o2.getPosition().x));
        }
    }

    public class PointYComparator implements Comparator<VertexPoint> {

        public int compare(VertexPoint o1, VertexPoint o2) {
            return (int) ((2 << 24) * (o1.getPosition().y - o2.getPosition().y));
        }
    }

    public class PointZComparator implements Comparator<VertexPoint> {

        public int compare(VertexPoint o1, VertexPoint o2) {
            return (int) ((2 << 24) * (o1.getPosition().z - o2.getPosition().z));
        }
    }

    private class VertexPoint {

        private Vector3f position;
        private int index;

        public VertexPoint(int index) {
            this.index = index;
        }

        public VertexPoint(int index, Vector3f position) {
            this.position = position;
            this.index = index;
        }

        public void updatePosition() {
            dataDisplay.getDynamicMesh().getVertexPosition(index, position);

        }

        public Vector3f getPosition() {

            return position;
        }
    }
}
