/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.flight.motion;

import com.jme3.bullet.objects.PhysicsRigidBody;
import com.jme3.math.Vector3f;

/**
 *
 * @author jonas.reinhardt
 */
public class MotionAi {


private Vector3f temp = new Vector3f();

private Vector3f lastTranslation = new Vector3f();

private Vector3f lastRotation=  new Vector3f();

private Vector3f currentTranslation =  new Vector3f();

private Vector3f currentRotation=  new Vector3f();


private Vector3f angularVelocity =  new Vector3f();

private Vector3f linearVelocity=  new Vector3f();


private Vector3f targetDeltaTranslation =  new Vector3f();

private Vector3f targetDeltaRotation=  new Vector3f();


private PhysicsRigidBody controlledBody;





public void update(){

controlledBody.getLinearVelocity(temp);
this.linearVelocity.set(temp.x, temp.y, temp.z);

controlledBody.getAngularVelocity(temp);
this.angularVelocity.set(temp.x, temp.y, temp.z);
}   



}
