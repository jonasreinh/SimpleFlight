package mygame;

import de.jo.gui.AxisViewController;
import com.jme3.app.SimpleApplication;
import com.jme3.app.StatsAppState;
import com.jme3.app.state.AppState;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.BulletAppState;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.system.AppSettings;
import de.jo.input.InputController;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector2f;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Geometry;
import com.jme3.scene.Mesh;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Sphere;
import com.jme3.util.SkyFactory;
import de.jo.flight.steering.SteeringController;
import de.jo.gui.GuiController;
import de.jo.gui.menu.ExtendedMenu;
import de.jo.gui.menu.item.SimpleMenuItem;
import de.jo.gui.menu.item.TextMenuItem;
import de.jo.gui.menu.item.input.SimpleFloatInputItem;
import de.jo.gui.menu.item.input.SimpleInputItem;
import de.jo.gui.menu.item.value.ValueMenuItem;
import de.jo.gui.menu.item.value.QuaternionMenuItem;
import de.jo.gui.menu.item.value.Vector2fMenuItem;
import de.jo.gui.menu.item.value.Vector3fMenuItem;
import de.jo.input.SimpleInputReceiverManager;
import de.jo.loader.mesh.AseLoader;
import de.jo.material.LogarithmicDepthManager;
import de.jo.mesh.MeshUtil;
import de.jo.terrain.LodInfo;
import de.jo.terrain.TerrainNode;
import de.jo.terrain.data.TerrainData;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * test
 *
 * @author normenhansen
 */
public class FlyApp extends SimpleApplication {
    DecimalFormat floatFormat = new DecimalFormat( "0.0" );
    
    private AxisViewController axisViewController;
    private SteeringController steeringController;
    private BulletAppState bulletAppState;
    // private InputController inputController;
    private ChaseCamera chaseCam;
    private Ship ship;
    private ExtendedMenu wm;
    private boolean debug = false;
    
    private Spatial sky;
    private Node skyNode = new Node("SkyNode");
    
    private TerrainNode terrainDisplay;
    private TerrainData terrainData = new TerrainData(5, 1, 3);
    
    private Vector3f sunVector = new Vector3f(10.2f,2.5f,-12).normalizeLocal();
    private LogarithmicDepthManager logarithmicDepthManager;

    public static void main(String[] args) {

        AppSettings newSetting = new AppSettings(true);
        newSetting.setFrameRate(60);
        newSetting.put("Width", 1024);

newSetting.put("Height", 768);

newSetting.put("Title", "Simple Flight Prototype");

newSetting.put("VSync", true);

        
        FlyApp app = new FlyApp(new StatsAppState());
        app.setShowSettings(false);
        app.setSettings(newSetting);
        app.start();
    }

    public FlyApp(AppState... initialStates) {
        super(initialStates);
    }
    

    @Override
    public void simpleInitApp() {
        //flyCam.setEnabled(false);
        //flyCam.setDragToRotate(true);
        
        inputManager.setCursorVisible(false);
        GuiController.getInstance().init(this);

        
        assetManager.registerLoader(AseLoader.class, "ase", "ASE");


        InputController.init(this.getTimer(), inputManager);

        this.axisViewController = new AxisViewController();

        this.steeringController = new SteeringController(getGuiController());




        bulletAppState = new BulletAppState();
        stateManager.attach(bulletAppState);
        //bulletAppState.setDebugEnabled(true);
        
        logarithmicDepthManager = LogarithmicDepthManager.getInstance();
        
        initWorld();
        
        initObjects();
        
        chaseCam = new ChaseCamera(cam, ship);
        
        
        logarithmicDepthManager.setCam(cam);
        logarithmicDepthManager.setzFar((float)0x1.0p64);
        logarithmicDepthManager.updateFrustum();        
        
        this.axisViewController.init(this, getChaseCam());

        initMenu();

        rootNode.attachChild(chaseCam.getCamNode());


        this.guiNode.attachChild(axisViewController);

        //inputManager.setCursorVisible(false);
        
        setDisplayFps(false);

        setDisplayStatView(false);
    }

    @Override
    public void reshape(int w, int h) {
        super.reshape(w, h);

        System.out.println("Reshape w: " + w + " h: " + h);
    }

    @Override
    public void simpleUpdate(float tpf) {
        //TODO: add update code

        wm.printMenu();

        steeringController.update();
        InputController.getInstance().update();


        terrainDisplay.updateTilesForPosition(cam.getLocation());



        //dataDisplay.setLocalRotation(cam.getRotation());
    }

    @Override
    public void simpleRender(RenderManager rm) {
        //TODO: add render code
    }

    public AxisViewController getGuiController() {
        return axisViewController;
    }

    public SteeringController getSteeringController() {
        return steeringController;
    }

    
    private void initWorld(){
        
        terrainDisplay = new TerrainNode(new LodInfo(16,8,10),4);
        terrainDisplay.init(this, bulletAppState.getPhysicsSpace());
        LogarithmicDepthManager.getInstance().addMaterial(terrainDisplay.getGroundMaterial());
        LogarithmicDepthManager.getInstance().addMaterial(terrainDisplay.getDebugMaterial());
        terrainDisplay.setHeightData(terrainData);
        rootNode.attachChild(terrainDisplay);
        
        
        sky = SkyFactory.createSky(assetManager, "Textures/Sky/FullskiesSunset0068.dds", false);
        sky.setLocalScale(350);
        
        skyNode.attachChild(sky);
        Mesh sunMesh = new Sphere(16, 16, 1.0f, false, false);
        MeshTools.moveVertexes(sunMesh, sunVector.mult(20));
        Geometry sunGeom = new Geometry ("SunGeom",sunMesh);
        
        sunGeom.setMaterial(assetManager.loadMaterial("Materials/SunMat.j3m"));
        sunGeom.setQueueBucket(RenderQueue.Bucket.Sky);
        sunGeom.setCullHint(Spatial.CullHint.Never);
        sunGeom.setModelBound(new BoundingSphere(Float.POSITIVE_INFINITY, Vector3f.ZERO));

        skyNode.attachChild(sunGeom);
        
        rootNode.attachChild(skyNode);
        
        DirectionalLight l = new DirectionalLight();
        //l.setDirection(new Vector3f(0.5973172f, -0.16583486f, 0.7846725f).normalizeLocal());
        l.setColor(new ColorRGBA(0.8f, 0.95f, 0.9f, 1));

        l.setDirection(sunVector.add(new Vector3f(0,0.4f,0)).normalize().mult(-1));
        rootNode.addLight(l);
        



        AmbientLight al = new AmbientLight();
        al.setColor(new ColorRGBA(0.2f, 0.1f, 0.4f, 0.1f));
        rootNode.addLight(al);    
        
    }
    
    private void initObjects() {

        ship = new Ship();
        ship.init(assetManager, bulletAppState.getPhysicsSpace());
        LogarithmicDepthManager.getInstance().addMaterial(ship.getShipGeometry().getMaterial());
        ship.getFlightControl().setPhysicsLocation(new Vector3f(0, 100, 0));
        bulletAppState.getPhysicsSpace().setGravity(Vector3f.ZERO);
        steeringController.setFlightControl(ship.getFlightControl());
        rootNode.attachChild(ship);
        
        Geometry geom = new Geometry();
        //flyCam.setDragToRotate(false);
        
    }

    public ChaseCamera getChaseCam() {
        return chaseCam;
    }

    private void initMenu() {
        SimpleInputReceiverManager.init();

        wm = new ExtendedMenu(cam, 5);
        
        initTerrainMenu();


        initInfoMenu();
        
        SimpleMenuItem speedInf = new SimpleMenuItem("Speed"){
            @Override
            public String toString() {
               return super.name +": "+ floatFormat.format(steeringController.getFlightControl().getLocalVel().z);//return super.toString(); //To change body of generated methods, choose Tools | Templates.
            }
          
        };
        wm.addMenuItem(speedInf);
        
        
        SimpleMenuItem switchWireframe = new SimpleMenuItem("WireFrame Mode"){
            @Override
            public void onActivate() {
                boolean wireFrame = terrainDisplay.getGroundMaterial().getAdditionalRenderState().isWireframe();
                if(wireFrame){
                    rootNode.attachChild(skyNode);
                            
                }else{
                    rootNode.detachChild(skyNode);
                }
                terrainDisplay.getGroundMaterial().getAdditionalRenderState().setWireframe(!wireFrame);
                super.onActivate(); //To change body of generated methods, choose Tools | Templates.
            }
            
            @Override
            public String toString() {
               return super.name +"("+(terrainDisplay.getGroundMaterial().getAdditionalRenderState().isWireframe() ?  'x': ' ')+")";//return super.toString(); //To change body of generated methods, choose Tools | Templates.
            }
          
        };
        wm.addMenuItem(switchWireframe);
        
        SimpleMenuItem switchDebug = new SimpleMenuItem("Debug Display"){
            @Override
            public void onActivate() {
                debug = !debug;
                if (debug) {
                    axisViewController.showDebug(true);
                    axisViewController.showAxisDisplay(true);
                    axisViewController.showzVecDisplay(true);
                    setDisplayFps(true);

                    setDisplayStatView(true);

                } else {
                    axisViewController.showDebug(false);
                    setDisplayFps(false);

                    setDisplayStatView(false);
                    axisViewController.showAxisDisplay(false);
                    axisViewController.showzVecDisplay(false);
                }
                
                super.onActivate(); //To change body of generated methods, choose Tools | Templates.
            }
            
            @Override
            public String toString() {
               return super.name +"("+(debug ?  'x': ' ')+")";//return super.toString(); //To change body of generated methods, choose Tools | Templates.
            }
          
        };
        wm.addMenuItem(switchDebug);

    }

    private void initInfoMenu() {
        SimpleMenuItem infoMenu = new SimpleMenuItem("Movement and Position info");

        QuaternionMenuItem qMI = new QuaternionMenuItem("world Rotation", wm) {
            @Override
            public Quaternion getValue() {
                return ship.getLocalRotation();
            }

            @Override
            public void setValueIntern(Quaternion value) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        infoMenu.addChild( qMI);

        SimpleMenuItem vMI = new Vector3fMenuItem("world Velocity", wm) {
            @Override
            public Vector3f getValue() {
                return steeringController.getFlightControl().getVelocity();
            }

            @Override
            public void setValueIntern(Vector3f value) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        infoMenu.addChild( vMI);

        SimpleMenuItem lvMI = new Vector3fMenuItem("local Velocity", wm) {
            @Override
            public Vector3f getValue() {
                return steeringController.getFlightControl().getLocalVel();
            }

            @Override
            public void setValueIntern(Vector3f value) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        infoMenu.addChild( lvMI);


       SimpleMenuItem lvoMI = new Vector3fMenuItem("local Velocity Orientation", wm) {
            @Override
            public Vector3f getValue() {
                return steeringController.getFlightControl().getLocalVelOri();
            }

            @Override
            public void setValueIntern(Vector3f value) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
       infoMenu.addChild( lvoMI);
       

        SimpleMenuItem posMI = new TextMenuItem("Vector Spherical Position", wm) {
            private DecimalFormat format = new DecimalFormat("0.000");

            {
                format.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
//format.applyLocalizedPattern("en_US");
            }

            @Override
            public String getValue() {
                Vector3f localVelOri = steeringController.getFlightControl().getLocalVelOri();
                return " ("+format.format(Math.acos(localVelOri.z))+","+format.format(Math.asin(localVelOri.x))+")";
            }
        };
      infoMenu.addChild( posMI);
      
      wm.addMenuItem(infoMenu);
    }

    private void initTerrainMenu() {
        SimpleMenuItem terrSet = new SimpleMenuItem("TerrainSettings");
        
        SimpleMenuItem fogDepthPow = new SimpleFloatInputItem("fogDepthPow",  1f/16) {
            @Override
            protected float getValue() {
                return (Float)terrainDisplay.getGroundMaterial().getParam("fogDepthPow").getValue();
            }

            @Override
            protected void setValue(float value) {
                terrainDisplay.getGroundMaterial().getParam("fogDepthPow").setValue(value);
            }
            
            
        };
        
        terrSet.addChild(fogDepthPow);
        
        SimpleMenuItem fogDepthHeightMixFac = new SimpleFloatInputItem("fogDepthHeightMixFac",  1f/16) {
            @Override
            protected float getValue() {
                return (Float)terrainDisplay.getGroundMaterial().getParam("fogDepthHeightMixFac").getValue();
            }

            @Override
            protected void setValue(float value) {
                terrainDisplay.getGroundMaterial().getParam("fogDepthHeightMixFac").setValue(value);
            }
            
            
        };
        
        terrSet.addChild(fogDepthHeightMixFac);
        
        SimpleMenuItem fogHeightMult = new SimpleFloatInputItem("fogHeightMult",  1f/16) {
            @Override
            protected float getValue() {
                return (Float)terrainDisplay.getGroundMaterial().getParam("fogHeightMult").getValue();
            }

            @Override
            protected void setValue(float value) {
                terrainDisplay.getGroundMaterial().getParam("fogHeightMult").setValue(value);
            }
            
            
        };
        
        terrSet.addChild(fogHeightMult);
        
        SimpleMenuItem fogHeightAdd = new SimpleFloatInputItem("fogHeightAdd",  1f/16) {
            @Override
            protected float getValue() {
                return (Float)terrainDisplay.getGroundMaterial().getParam("fogHeightAdd").getValue();
            }

            @Override
            protected void setValue(float value) {
                terrainDisplay.getGroundMaterial().getParam("fogHeightAdd").setValue(value);
            }
            
            
        };
        
        terrSet.addChild(fogHeightAdd);
        
        wm.addMenuItem(terrSet);
    }
}
