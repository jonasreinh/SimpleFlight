/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.RawInputListener;
import com.jme3.input.event.JoyAxisEvent;
import com.jme3.input.event.JoyButtonEvent;
import com.jme3.input.event.KeyInputEvent;
import com.jme3.input.event.MouseButtonEvent;
import com.jme3.input.event.MouseMotionEvent;
import com.jme3.input.event.TouchEvent;
import com.jme3.math.Vector2f;
import com.jme3.system.Timer;
import de.jo.input.InputActivation.InputSource;
import de.jo.input.InputActivation.InputType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 *
 * @author jonas.reinhardt
 */
public class InputController implements RawInputListener {

    //private static List<Integer>[] pressedButtonCodes = new List[3];
    public static final int inputSourceCount = InputSource.values().length;
    public static final int inputTypeCount = InputType.values().length;
    private static InputController instance;
    private Map<Integer, PressedButtonlInfo>[] activeInputActions = new Map[inputSourceCount * inputTypeCount];
    private Map<Integer, List<InputAction>>[] inputActionMaps = new Map[2 * InputType.values().length * InputSource.values().length];
    private Queue<ActivationInfo> activationQueue = new ConcurrentLinkedQueue<>();
    private List<InputAction> activeActions = new LinkedList<>();
    private List<InputAction> addedActions = new LinkedList<>();
    
    private InputManager inputManager;
    private Timer timer;
    
    private int mouseX;
    private int mouseY;

    //private MouseButtonEvent lastMouseButtonEvent;
    public static void init(Timer timer, InputManager inputManager) {


        if (instance == null) {
            instance = new InputController(timer, inputManager);
        } else {
            throw new UnsupportedOperationException("Instace for '" + InputController.class.getName() + "' already exists");
        }

         InputAction showInputActions = new InputAction("Show InputActions", false) {
            private boolean cameraControl = false;

            @Override
            public void onAction(float timeVal, float axisVal) {
                System.out.println("Printing InputActions: ");
               List<InputAction> inputActions = InputController.getInstance().getAddedActions();

                for (InputAction ia : inputActions) {
                    System.out.println("Action: " + ia.getName() + " Activation: [" + ia.getActivationsString() + "]");
                }
            }

        };
         showInputActions.getRequiredActivations().add(new InputActivation(true, InputType.BUTTON, InputSource.KEYBOARD, KeyInput.KEY_F1));
         instance.addInputAction(showInputActions);
         
    }

    private InputController(Timer timer, InputManager inputManager) {
        //System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");  

        this.inputManager = inputManager;
        this.timer = timer;

        inputManager.addRawInputListener(this);
        for (int i = 0; i < activeInputActions.length; i++) {
            activeInputActions[i] = new HashMap<>();
        }


        //pressedButtonCodes[InputMapping.INPUTSOURCE_Key] = new ArrayList<Integer>();
        // pressedButtonCodes[InputMapping.INPUTSOURCE_Mouse] = new ArrayList<Integer>();

        for (int i = 0; i < inputActionMaps.length; i++) {

            inputActionMaps[i] = new HashMap<Integer, List<InputAction>>();
        }

    }

    public InputManager getInputManager() {
        return inputManager;
    }

    public static InputController getInstance() {
        return instance;
    }

    public List<InputAction> getAddedActions() {
        return addedActions;
    }


    
    
    
    public void addInputAction(InputAction inputAction) {
        //To change body of generated methods, choose Tools | Templates.

        addedActions.add(inputAction);
        for (InputActivation inputActivation : inputAction.getRequiredActivations()) {
            Map<Integer, List<InputAction>> inputActionMap = getInputActivationMap(inputActivation);

            int inputActivationCode = inputActivation.getInputActivationCode();
            if (!inputActionMap.containsKey(inputActivationCode)) {
                
                inputActionMap.put(inputActivationCode, new ArrayList<InputAction>());
            }
            
            inputActionMap.get(inputActivationCode).add(inputAction);
        }
        inputAction.onAdded();

    }
    
    
    public void removeInputAction(InputAction inputAction) {
        //To change body of generated methods, choose Tools | Templates.

        for (InputActivation inputActivation : inputAction.getRequiredActivations()) {
            Map<Integer, List<InputAction>> inputActionMap = getInputActivationMap(inputActivation);

            int inputActivationCode = inputActivation.getInputActivationCode();
            
            if (inputActionMap.containsKey(inputActivationCode)) {

                inputActionMap.get(inputActivationCode).remove(inputAction);
            }else{
                throw new UnsupportedOperationException("InputActionList for '"+inputActivationCode+"' not found in "+inputActionMap);
            }
         
        }
        addedActions.remove(inputAction);
        inputAction.onRemoved();
    }
    

    private Map<Integer, List<InputAction>> getInputActivationMap(InputType inputType, InputSource inputSource) {

        return inputActionMaps[ InputSource.values().length * inputType.ordinal() + inputSource.ordinal()];
    }

    private Map<Integer, List<InputAction>> getInputActivationMap(InputActivation inputActivation) {
        return getInputActivationMap(inputActivation.getInputType(), inputActivation.getInputSource());
    }

    public void onJoyAxisEvent(JoyAxisEvent evt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void onJoyButtonEvent(JoyButtonEvent evt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void onMouseMotionEvent(MouseMotionEvent evt) {
        // System.out.println("onMouseMotionEvent dx: " + evt.getDX() + " dy: " + evt.getDY());
        int dx = evt.getDX();
        int dy = evt.getDY();

        // Map<Integer, List<InputAction>> mouseInputActivationMap = getInputActivationMap(InputType.AXIS, InputSource.MOUSE);

        mouseX = evt.getX();
        mouseY = evt.getY();
        if (dx != 0) {
            onAxisEvent(InputSource.MOUSE, MouseInput.AXIS_X, dx);
        }

        if (dy != 0) {
            onAxisEvent(InputSource.MOUSE, MouseInput.AXIS_Y, dy);
        }
        
    }

    public int getMouseX() {
        return mouseX;
    }

    public int getMouseY() {
        return mouseY;
    }

    
    
    public void onMouseButtonEvent(MouseButtonEvent evt) {
        //System.out.println("onMouseButtonEvent");
        //System.out.println(" evt.isPressed(: "+evt.isPressed()+" evt.isReleased(): "+evt.isReleased()+" evt: "+evt.hashCode());
        // if(lastMouseButtonEvent==null ||(lastMouseButtonEvent.hashCode()!=evt.hashCode() )){
        // lastMouseButtonEvent = evt;
        // 
        onButtonEvent(false, evt.isPressed(), evt.isReleased(), InputSource.MOUSE, evt.getButtonIndex());

        //}


    }

    public void onKeyEvent(KeyInputEvent evt) {


        int code = evt.getKeyCode();

        onButtonEvent(evt.isRepeating(), evt.isPressed(), evt.isReleased(), InputSource.KEYBOARD, evt.getKeyCode());

        /* String pressedKeys = "";
         for (Integer pressedCode : pressedButtonCodes[InputMapping.INPUTSOURCE_Key]) {
         pressedKeys += pressedCode + ",";
         }

         System.out.println("pressedKeys: " + pressedKeys);*/
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Map<Integer, PressedButtonlInfo> getActiveInputActionsMap(InputSource source, InputType type) {
        return activeInputActions[source.ordinal() * inputTypeCount + type.ordinal()];
    }

    public boolean isActivationActive(InputActivation inputActivation) {

        return inputActivation.isPressed() == getActiveInputActionsMap(inputActivation.getInputSource(), inputActivation.getInputType()).containsKey(inputActivation.getInputActivationCode());

    }

    public boolean isInputActionOperational(InputAction inputAction) {


        for (InputActivation activation : inputAction.getRequiredActivations()) {
            boolean active = isActivationActive(activation);
            //System.out.println("checking " + activation + " : " + active);
            if (!active) {
                return false;
            }
        }

        return true;
    }

    private void onAxisEvent(InputSource inputSource, int inputCode, float axisVal) {

        List<InputAction> inputActions = getInputActivationMap(InputType.AXIS, inputSource).get(inputCode);
        long time = timer.getTime();

        PressedButtonlInfo activeControlInfo;

        // System.out.println("onKeyEvent " + evt.getKeyCode() + " pressed: " + evt.isPressed() + " released: " + evt.isReleased() + " repeating: " + evt.isRepeating());
        // System.out.println(" " + inputSource.name() + " [" + inputCode + "] pressed! ");
        activeControlInfo = new PressedButtonlInfo();

        activeControlInfo.setControlCode(inputCode);
        activeControlInfo.setActivationBegin(inputCode);
        getActiveInputActionsMap(inputSource, InputType.AXIS).put(inputCode, activeControlInfo);
        updateInputActions(inputActions, time, axisVal);
        getActiveInputActionsMap(inputSource, InputType.AXIS).remove(inputCode);

    }

    private void onButtonEvent(boolean repeating, boolean pressed, boolean released, InputSource inputSource, int inputCode) {

        List<InputAction> inputActions = getInputActivationMap(InputType.BUTTON, inputSource).get(inputCode);
        long time = timer.getTime();

        PressedButtonlInfo activeControlInfo;
        //System.out.println("InputSource ("+inputSource.ordinal()+") ActiveActions0: "+getActiveInputActionsMap(inputSource,InputType.BUTTON).size());
        if (!getActiveInputActionsMap(inputSource, InputType.BUTTON).containsKey(inputCode)) {
            // System.out.println("onKeyEvent " + evt.getKeyCode() + " pressed: " + evt.isPressed() + " released: " + evt.isReleased() + " repeating: " + evt.isRepeating());
            //System.out.println(" " + inputSource.name() + " [" + inputCode + "] pressed! ");
            activeControlInfo = new PressedButtonlInfo();

            activeControlInfo.setControlCode(inputCode);
            activeControlInfo.setActivationBegin(inputCode);
            getActiveInputActionsMap(inputSource, InputType.BUTTON).put(inputCode, activeControlInfo);
            //System.out.println("Put activeControlInfo: "+inputCode+" in "+inputSource.ordinal());
            updateInputActions(inputActions, time, 0);
        } else {
            activeControlInfo = getActiveInputActionsMap(inputSource, InputType.BUTTON).get(inputCode);
        }

        if (!repeating) {
            if (pressed) {
            }

            if (released) {
                //System.out.println(" " + inputSource.name() + " [" + inputCode + "] released! ");
                getActiveInputActionsMap(inputSource, InputType.BUTTON).remove(inputCode);
                // System.out.println("remove activeControlInfo: "+inputCode+" in "+inputSource.ordinal());
                // System.out.println("B");
                updateInputActions(inputActions, time, 0);

            }
        }

        // System.out.println("InputSource ("+inputSource.ordinal()+") ActiveActions1: "+getActiveInputActionsMap(inputSource,InputType.BUTTON).size());
    }

    public void beginInput() {
        // System.out.println("beginInput");
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void endInput() {
        //System.out.println("endInput");
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void onTouchEvent(TouchEvent evt) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void update() {

        long time = timer.getTime();

        //System.out.println("queue size: "+activationQueue.size());
        while (activationQueue.size() > 0) {

            ActivationInfo activationInfo = activationQueue.poll();

            // System.out.println(" Applying "+activationInfo.getInputAction());
            activationInfo.getInputAction().onAction(activationInfo.getActivationValue() * (1f / timer.getResolution()), activationInfo.getInputAction().value);
            activationInfo.getInputAction().value = 0;
        }


        for (InputAction inputAction : activeActions) {
            //System.out.println(" updating active Action");
            inputAction.onAction((time - inputAction.getLastActionTime()) * (1f / timer.getResolution()), inputAction.value);

            inputAction.value = 0;

            inputAction.setLastActionTime(time);
        }

    }

    private void updateInputActions(List<InputAction> inputActions, long time, float axisVal) {
        //System.out.println("updating Input Actions (" + (inputActions != null ? inputActions.size() : null) + ")");
        if (inputActions != null) {


            for (InputAction inputAction : inputActions) {


                boolean operational = isInputActionOperational(inputAction);
                if (operational) {

                    inputAction.value += axisVal;
                }
                // System.out.println("operational: " + operational + " oldOpVal: " + inputAction.isOperational() + " repeating: " + inputAction.isRepeating());

                if (!operational && inputAction.isOperational()) {

                    if (inputAction.isRepeating()) {

                        ///System.out.println("removing active action");
                        ActivationInfo activationInfo = new ActivationInfo(inputAction.getLastActionTime() != 0 ? time - inputAction.getLastActionTime() : 0, inputAction);
                        activationQueue.add(activationInfo);
                        activeActions.remove(inputAction);
                        inputAction.setOperational(false);
                        // inputAction.setLastActionTime(0);
                    } else {
                    }
                    inputAction.setLastActionTime(time);
                } else if (operational && !inputAction.isOperational()) {

                    if (inputAction.isRepeating()) {

                        //System.out.println("adding active action");
                        //inputAction.setLastActionTime(time);

                        activeActions.add(inputAction);
                        inputAction.setOperational(true);
                    } else {

                        // System.out.println("adding action to queue");
                        ActivationInfo activationInfo = new ActivationInfo(time, inputAction);
                        activationQueue.add(activationInfo);
                        // System.out.println("queue size: " + activationQueue.size());
                    }
                    inputAction.setLastActionTime(time);
                }

            }
        }
    }

    public class PressedButtonlInfo {

        private InputSource inputSource;
        private int controlCode;
        private long activationBegin;

        public int getControlCode() {
            return controlCode;
        }

        public void setControlCode(int controlCode) {
            this.controlCode = controlCode;
        }

        public long getActivationBegin() {
            return activationBegin;
        }

        public void setActivationBegin(long activationBegin) {
            this.activationBegin = activationBegin;
        }

        public InputSource getInputSource() {
            return inputSource;
        }

        public void setInputSource(InputSource inputSource) {
            this.inputSource = inputSource;
        }
    }
}
