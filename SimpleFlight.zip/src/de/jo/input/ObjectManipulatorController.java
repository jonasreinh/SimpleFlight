/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author jonas.reinhardt
 */
public class ObjectManipulatorController {

    private static ObjectManipulatorController instance = new ObjectManipulatorController();
    private Map<Class<? extends ObjectManipulator>, ObjectManipulator> objectManipulatorMap = new HashMap<>();
    private ObjectManipulator activeManipulator;

    public Map<Class<? extends ObjectManipulator>, ObjectManipulator> getObjectManipulatorMap() {
        return objectManipulatorMap;
    }

    public void setObjectManipulatorMap(Map<Class<? extends ObjectManipulator>, ObjectManipulator> objectManipulatorMap) {
        this.objectManipulatorMap = objectManipulatorMap;
    }

    public ObjectManipulator getActiveManipulator() {
        return activeManipulator;
    }

    public void setActiveManipulator(ObjectManipulator activeManipulator) {
        if (this.activeManipulator != activeManipulator) {
            if (this.activeManipulator != null) {
                this.activeManipulator.setActivated(false);
            }
            this.activeManipulator = activeManipulator;
            if (activeManipulator != null) {
                activeManipulator.setActivated(true);
            }
        }

    }

    public void addObjectManipulator(ObjectManipulator objectManipulator) {
        objectManipulatorMap.put(objectManipulator.getClass(), objectManipulator);
    }

    public <T extends ObjectManipulator> T getObjectManipulator(Class<T> objMClass) {
        if (!objectManipulatorMap.containsKey(objMClass)) {
            try {
                objectManipulatorMap.put(objMClass, objMClass.newInstance());
            } catch (Exception e) {
                objectManipulatorMap.put(objMClass, null);
                e.printStackTrace();
            }
        }
        return (T) objectManipulatorMap.get(objMClass);
    }

    public static ObjectManipulatorController getInstance() {
        return instance;
    }
}
