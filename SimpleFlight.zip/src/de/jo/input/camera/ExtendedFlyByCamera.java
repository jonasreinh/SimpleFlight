/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input.camera;

import com.jme3.input.FlyByCamera;
import com.jme3.renderer.Camera;

/**
 *
 * @author User
 */
public class ExtendedFlyByCamera extends FlyByCamera{



    
    public ExtendedFlyByCamera(Camera cam) {
        super(cam);
    }

    public Camera getCam() {
        return cam;
    }

    
    
}
