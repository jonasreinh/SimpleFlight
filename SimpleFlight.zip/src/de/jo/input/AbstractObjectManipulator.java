/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

/**
 *
 * @author jonas.reinhardt
 */
public abstract class AbstractObjectManipulator <T> implements ObjectManipulator<T>{

    protected T object;
    
    protected boolean activated;
    
    @Override
    public T getObject() {
       return object;
    }

    @Override
    public void setObject(T object) {
        this.object = object;//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public abstract void setValue(int id, float value);
    
    
    @Override
    public boolean isActivated() {
        return activated;
    }
    
    @Override
    public void setActivated(boolean activated) {
        this.activated = activated;
    }
    
    
    
}
