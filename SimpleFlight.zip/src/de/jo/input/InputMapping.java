/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *
 * @author jonas.reinhardt
 */
@Retention( value = RetentionPolicy.RUNTIME)
@Target( java.lang.annotation.ElementType.METHOD)
public @interface InputMapping {

    
    /*public static final int VALUECOUNT_INPUTTYPE = 2;
    
    public static final int INPUTTYPE_Button = 0;
    public static final int INPUTTYPE_Axis = 1;
    
    
    public static final int VALUECOUNT_INPUTSOURCE = 2;
    public static final int INPUTSOURCE_Key = 0;
    public static final int INPUTSOURCE_Mouse = 1;*/
    
    
    /*public enum Button{KEY_ESCAPE,KEY_1,KEY_2,KEY_3,KEY_4,KEY_5,KEY_6,KEY_7,KEY_8,KEY_9,KEY_0,
     KEY_MINUS,KEY_EQUALS,KEY_BACK,KEY_TAB,KEY_Q,KEY_W,KEY_E,KEY_R
     KEY_T,KEY_Y,KEY_U,,BUTTON_LEFT,BUTTON_RIGHT,BUTTON_MIDDLE}*/
    //public static final int AXIS_MOUSE = 0;

    
    /**
     * A name for the action. This can be referenced later
     * @return 
     */
    String actionName();
    
    /**
     * Define 3 int values (Input type, Input source, specific input id) for every Key Button or Axis which has to be active to activate the Action.
     * <br><br>
     * For Example Mouse X Axis + left CTRL:<br><br>
     * activationInput = {de.jo.input.InputMapping.INPUTTYPE_Axis,de.jo.input.InputMapping.INPUTSOURCE_Mouse,com.jme3.input.MouseInput.AXIS_X,
        de.jo.input.InputMapping.INPUTTYPE_Button,de.jo.input.InputMapping.INPUTSOURCE_Key,com.jme3.input.KeyInput.KEY_LCONTROL}
     */
    int[] activationInput();
    
    boolean repeating();

}
