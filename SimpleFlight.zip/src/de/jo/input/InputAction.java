/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

import java.util.ArrayList;
import java.util.List;

public abstract class InputAction {

    private List<InputActivation> requiredActivations = new ArrayList<InputActivation>();
    //private Method actionMethod;
    private Object object;
    private boolean repeating = false;
    private long lastActionTime = 0;
    private boolean operational = false;
    private String name;
    public float value;

    public InputAction(String name, boolean repeating) {
        this.name = name;
        this.repeating = repeating;
    }

    public List<InputActivation> getRequiredActivations() {
        return requiredActivations;
    }

    public boolean isOperational() {
        return operational;
    }

    public void setOperational(boolean operational) {
        this.operational = operational;
    }

    public long getLastActionTime() {
        return lastActionTime;
    }

    public void setLastActionTime(long lastActionTime) {
        this.lastActionTime = lastActionTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public void onAdded() {
    }

    ;
         public void onRemoved() {
    }

    ;
         
        public abstract void onAction(float timeVal, float axisVal);

    /* public Method getActionMethod() {
     return actionMethod;
     }

     public void setActionMethod(Method actionMethod) {
     this.actionMethod = actionMethod;
     }*/
    public boolean isRepeating() {
        return repeating;
    }

    public void setRepeating(boolean repeating) {
        this.repeating = repeating;
    }

    public String getActivationsString() {

        String activationsString = "";
        if (this.requiredActivations != null) {
            for (InputActivation iA : requiredActivations) {
                activationsString += (iA.isPressed() ? "+" : "-") + iA.getInputCodeString() + ", ";
            }
            if (activationsString.length() > 1) {
                activationsString = activationsString.substring(0, activationsString.length() - 2);
            }
        }
        return activationsString;
    }

    @Override
    public String toString() {
        return "InputAction{'" + name + "' repeating[" + repeating + "]}";
    }

}
