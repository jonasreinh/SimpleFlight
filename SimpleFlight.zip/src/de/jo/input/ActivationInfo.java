/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

public class ActivationInfo {

        private long activationValue;
        private InputAction inputAction;

        public ActivationInfo(long activationValue, InputAction inputAction) {
            this.activationValue = activationValue;
            this.inputAction = inputAction;
        }

        public long getActivationValue() {
            return activationValue;
        }

        public InputAction getInputAction() {
            return inputAction;
        }

        public void setInputAction(InputAction inputAction) {
            this.inputAction = inputAction;
        }

        public void setActivationValue(long activationValue) {
            this.activationValue = activationValue;
        }
    }