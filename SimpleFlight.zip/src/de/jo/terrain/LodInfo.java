/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.terrain;

/**
 *
 * @author User
 */
public class LodInfo {
    public int segmentCount;// = 1;
    public int segmentBaseSize;// = 2;
    public int segmentSizeShiftPerLod = 1;
    //private int tileSize = segmentBaseSize * segmentCount;
    public int lodLevels;// = 2;


    public LodInfo(int segmentCount, int segmentBaseSize, int lodLevels) {
        this.segmentCount = segmentCount;
        this.segmentBaseSize = segmentBaseSize;
        this.lodLevels = lodLevels;
        
    }
    
    public int getVisualSegmentSize(int visualLodIndex) {

        return (segmentBaseSize << (segmentSizeShiftPerLod * visualLodIndex));

    }

    
    public int getVisualResolutionSize(int visualLodIndex) {

        return  (segmentBaseSize << (segmentSizeShiftPerLod * visualLodIndex));

    }
    
    public int getVisualTileSize(int visualLodIndex) {

        return segmentCount * (segmentBaseSize << (segmentSizeShiftPerLod * visualLodIndex));

    }
    
    
}
