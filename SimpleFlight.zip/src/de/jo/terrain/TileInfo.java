/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.terrain;

public class TileInfo implements Comparable<TileInfo> {

        public float posX;
        public float posZ;
        public int lod;

    public TileInfo() {
    }

    public TileInfo(int lod,float posX, float posZ) {
        this.posX = posX;
        this.posZ = posZ;
        this.lod = lod;
    }

        
        public TileInfo clone(){
            return new TileInfo(lod,posX,posZ);
        }
        
        public int compareTo(TileInfo o) {
            float val =o.lod- this.lod ;
            if (val == 0) {
                val =  o.posX-this.posX;
                if (val == 0) {
                    val = o.posZ-this.posZ;
                }
            }
            return (int) val;
        }

        @Override
        public String toString() {
            return "["+lod+"]("+posX+","+posZ+")"; //To change body of generated methods, choose Tools | Templates.
        }
   
    }