/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.material;

import com.jme3.material.Material;
import com.jme3.renderer.Camera;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jonas.reinhardt
 */
public class LogarithmicDepthManager {

    private static LogarithmicDepthManager instance = new LogarithmicDepthManager();
    private float C = 1.0f;
    private float logDepthK;
    private float zFar;
    private float zNear;
    private Camera cam;
    private List<Material> materials = new ArrayList<Material>();

    public Camera getCam() {
        return cam;
    }

    public void setCam(Camera cam) {
        this.cam = cam;
        this.zFar = cam.getFrustumFar();
        this.zNear = cam.getFrustumNear();
        updateFrustum();
    }

    
    public void addMaterial(Material material) {
        insertValues(material);
        materials.add(material);

    }

    public void removeMaterial(Material material) {

        materials.remove(material);
    }

    
    
    
    public void updateFrustum() {


        

       // zFar *= factor;

        cam.setFrustumFar(zFar);
        cam.setFrustumNear(zNear);

        logDepthK = (float) (2.0/Math.log(zFar+1.0)/Math.log(2.0));//(float)(1.0/Math.log(C * zFar + 1.0));//(float) (2.0 / Math.log(C * zFar + 1.0));


        onValueChanged();

        //cam.setFrustumNear(newFrustumFar/(1<<16));
    }

    private void onValueChanged() {
        System.out.println("New Frustum : " + zNear + " , " + zFar + " logDepthK: " + logDepthK + " C: " + C);
        for (Material material : materials) {
            insertValues(material);
        }
    }

    private void insertValues(Material material) {
        // System.out.println("Setting Values for "+material);
        material.setFloat("C", C);
        material.setFloat("zf", zFar);
        material.setFloat("LogDepthK", logDepthK);
        material.setFloat("LogDepthKHalf", logDepthK*0.5f);
    }

    public static LogarithmicDepthManager getInstance() {
        return instance;
    }

    public float getC() {
        return C;
    }

    public void setC(float C) {
        this.C = C;
        onValueChanged();
    }

    public float getzFar() {
        return zFar;
    }

    public void setzFar(float zFar) {
        this.zFar = zFar;
    }

    public float getzNear() {
        return zNear;
    }

    public void setzNear(float zNear) {
        this.zNear = zNear;
    }
 
}
