/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui;

import com.jme3.app.SimpleApplication;
import com.jme3.font.BitmapFont;
import com.jme3.font.BitmapText;
import com.jme3.font.Rectangle;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 *
 * @author jonas.reinhardt
 */
public class GuiController {//

    public static final NumberFormat numberFormat = new DecimalFormat("#0.00000");
    private SimpleApplication simpleApplication;
    
    private BitmapText logDisplay;
    private int maxLogLines = 5;
    private int currLogLines = 0;
    
    BitmapFont textFont;
    private static GuiController instance = new GuiController();

    public void init(SimpleApplication simpleApplication) {


        this.simpleApplication = simpleApplication;
        textFont = simpleApplication.getAssetManager().loadFont("Interface/Fonts/Default.fnt");
 

        logDisplay = createBitMapText(200, (maxLogLines + 1) * textFont.getPreferredSize(),300,0);
       /* logDisplay.setBox(new Rectangle(0, 0, 300, 0));
        logDisplay.setSize(fnt.getPreferredSize() * 1f);
        logDisplay.setLocalTranslation(, 0);
        simpleApplication.getGuiNode().attachChild(logDisplay);*/
        //logDisplay.setText("test \n test \n test \n test \n test");


    }

    public BitmapText createBitMapText(float x, float y, float width, float height){
      BitmapText  bitMapText = new BitmapText(textFont, false);
        bitMapText.setBox(new Rectangle(0, 0, width, height));//300
        bitMapText.setSize(textFont.getPreferredSize() * 1f);
        bitMapText.setLocalTranslation(x,y , 0);//
        simpleApplication.getGuiNode().attachChild(bitMapText);
        
        return bitMapText;
    }
    
    public void removeBitmapText(BitmapText  bitMapText){
        
        simpleApplication.getGuiNode().detachChild(bitMapText);
    }
    
    public void initLog() {
    }

    public BitmapFont getTextFont() {
        return textFont;
    }

    

   

    public void clearLogText() {
        this.logDisplay.setText("");
        this.currLogLines = 0;

    }

    public static GuiController getInstance() {
        return instance;
    }

    /*@Override
    public void log(String preText, String text) {
       
      String currLogText = logDisplay.getText();
        if (currLogLines < maxLogLines) {

            currLogLines++;
        } else {

            int firstLineEnd = currLogText.indexOf("\n");

            currLogText = currLogText.substring(firstLineEnd + 1);
        }
        String newLogText = "";
        if(preText!=null&&preText.length() >0){
            newLogText+="["+preText+"]: ";
        }
        newLogText += text;
        logDisplay.setText(currLogText + "\n" + newLogText);   
        
    }*/

    public static NumberFormat getNumberFormat() {
        return numberFormat;
    }
    
    
    
}
