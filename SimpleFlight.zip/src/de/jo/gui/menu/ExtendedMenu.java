/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu;

import de.jo.gui.GuiController;
import com.jme3.font.BitmapText;
import com.jme3.input.KeyInput;
import com.jme3.renderer.Camera;
import de.jo.gui.menu.item.value.NumberManipulatorItem;



import de.jo.input.InputAction;
import de.jo.input.InputActivation;
import de.jo.input.InputController;

/**
 *
 * @author jonas.reinhardt
 */
public class ExtendedMenu extends SimpleMenu {


    private BitmapText menuDisplay;
    private int menuHeight = 10;

    public ExtendedMenu(Camera camera, int pageSize) {
        super(pageSize);

        menuDisplay = GuiController.getInstance().createBitMapText(0, camera.getHeight() - menuHeight, camera.getWidth(), 0);

        //this.worldApp = worldApp;
        InputAction cursorDown = new InputAction("cursorDown", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {
                moveCursor(1);
                printMenu();
            }
        };
        cursorDown.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_PGDN));
        InputController.getInstance().addInputAction(cursorDown);

        InputAction cursorUp = new InputAction("cursorUp", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {
                moveCursor(-1);
                printMenu();
            }
        };
        cursorUp.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_PGUP));
        InputController.getInstance().addInputAction(cursorUp);

        InputAction cursorForwardAction = new InputAction("cursorForward", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {
                cursorForward();
                printMenu();
            }
        };
        cursorForwardAction.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_RETURN));
        InputController.getInstance().addInputAction(cursorForwardAction);

        InputAction cursorBackwardAction = new InputAction("cursorBackward", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {
                cursorBackward();
                printMenu();
            }
        };
        cursorBackwardAction.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_BACK));
        InputController.getInstance().addInputAction(cursorBackwardAction);


       



    }

    //private Map<String, ValueManipulator> valueMapilulatorMap = new HashMap<String, ValueManipulator>();
   /* public void addValueManipulator(SimpleMenuItem menuItem, final ValueManipulator manipulator) {

        if (menuItem == null) {
            menuItem = rootItem;
        }

        SimpleMenuItem manipulatorItem = new SimpleMenuItem(manipulator.getName()) {
            @Override
            public void onActivate() {
                setSelectedValueManipulator(manipulator);
            }
        };
        menuItem.getChildren().add(manipulatorItem);

    }

    public void setSelectedValueManipulator(ValueManipulator selectedValueManipulator) {
        this.selectedValueManipulator = selectedValueManipulator;
        System.out.println(" Value Manipulator '" + selectedValueManipulator + "' selected");
    }

    public void manipulateValue(ValueManipulator manipulator, float factor) {

        if (manipulator != null) {
            float oldVal = manipulator.getValue();

            float newVal = oldVal * factor;
            //System.out.println(oldVal+"*"+factor+"= "+newVal);
            manipulator.setValue(newVal);
            GuiController.getInstance().log(manipulator.getName(), "" + newVal);//.printLogText(manipulator.getName() +  newVal);


        }

    }

    /*private void setSelectedValue(M selectedValue) {
     this.selectedValueManipulator = selectedValue;
     System.out.println("SelectedValue: " + selectedValue);
     }*/
    /*public static abstract class ValueManipulator {

        private String name;

        public String getName() {
            return name;
        }

        public ValueManipulator(String name) {
            this.name = name;
        }

        public abstract float getValue();

        public abstract void setValue(float newValue);
    }*/

    @Override
    public void printMenu() {
        //super.printMenu(); //To change body of generated methods, choose Tools | Templates.
        //GuiController.getInstance().printMenuText(getMenuTxt());
        menuDisplay.setText(getMenuTxt());
    }
}
