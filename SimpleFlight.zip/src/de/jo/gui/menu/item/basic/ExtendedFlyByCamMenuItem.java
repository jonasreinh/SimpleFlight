/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.basic;

import com.jme3.input.FlyByCamera;
import com.jme3.renderer.Camera;
import de.jo.gui.menu.item.input.SimpleInputItem;
import de.jo.gui.menu.item.SimpleMenuItem;
import de.jo.input.SimpleInputReceiverManager;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueInc;
import de.jo.input.camera.ExtendedFlyByCamera;

/**
 *
 * @author User
 */
public class ExtendedFlyByCamMenuItem extends SimpleMenuItem{
    
private ExtendedFlyByCamera extendedFlyByCamera;

    public ExtendedFlyByCamMenuItem(String name,final ExtendedFlyByCamera extendedFlyByCamera) {
        super(name);
        this.extendedFlyByCamera = extendedFlyByCamera;
        
        this.addChild(new SimpleMenuItem("Position: "){

            @Override
            public String toString() {
                return name + extendedFlyByCamera.getCam().getLocation(); //To change body of generated methods, choose Tools | Templates.
            }
            
        
        });
        
        this.addChild(new SimpleInputItem("MoveSpeed: "){

            @Override
            public String toString() {
                return name + extendedFlyByCamera.getMoveSpeed(); //To change body of generated methods, choose Tools | Templates.
            }
            
            
            @Override
            public void onValueAction(SimpleInputReceiverManager.SimpleInputReceiver.InputValue inputValue, float timeVal, float axisVal, boolean repeating) {
                
                switch(inputValue){
                    case valueInc:
                        extendedFlyByCamera.setMoveSpeed(extendedFlyByCamera.getMoveSpeed()+0.125f*extendedFlyByCamera.getMoveSpeed());
                    break;
                         case valueDec:
                        extendedFlyByCamera.setMoveSpeed(extendedFlyByCamera.getMoveSpeed()-0.125f*extendedFlyByCamera.getMoveSpeed());
                    break;
                }
            }
            
        
        });
    }



    
    
}
