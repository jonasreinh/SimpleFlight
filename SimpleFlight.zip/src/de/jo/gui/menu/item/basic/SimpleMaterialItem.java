/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.basic;

import com.jme3.material.MatParam;
import com.jme3.material.Material;
import com.jme3.scene.Geometry;
import de.jo.gui.menu.item.SimpleMenuItem;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 *
 * @author User
 */
public class SimpleMaterialItem extends SimpleMenuItem {

    private Material material;
    private DecimalFormat format = new DecimalFormat("0.000");

    {
        format.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
    }
   

    public SimpleMaterialItem( String name, Material materialIn) {
        super(name);
        this.material = materialIn;
        
        SimpleMenuItem addRSItem = new SimpleMenuItem("AdditionalRenderState");
        
        addRSItem.addChild(new SimpleMenuItem("WireframeMode: "){

            @Override
            public void onActivate() {
                super.onActivate(); //To change body of generated methods, choose Tools | Templates.
                if(material!=null){
                    material.getAdditionalRenderState().setWireframe(!material.getAdditionalRenderState().isWireframe());
                }
            }

            @Override
            public String toString() {
                return name + (material!=null ? material.getAdditionalRenderState().isWireframe(): "n/a"); //To change body of generated methods, choose Tools | Templates.
            }
            
        
        });
        this.addChild(addRSItem);
        
        
        SimpleMenuItem paramsItem = new SimpleMenuItem("Parameters");
        
        if(material!=null){
         for(MatParam param : material.getParams()){   
          paramsItem.addChild(new SimpleMenuItem(param.getName()+": "+param.getValueAsString()+" ("+param.getVarType().name()+")"));
             
         }   
        }
        
        
        
       this.addChild(paramsItem);
    }

    @Override
    public String toString() {
        return name+ (material!=null ? material.getMaterialDef().getAssetName() : "n/a"); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
}
