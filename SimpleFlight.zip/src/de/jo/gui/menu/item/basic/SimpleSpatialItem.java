/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.basic;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Spatial;
import de.jo.gui.menu.item.SimpleMenuItem;
import de.jo.gui.menu.item.input.SimpleInputItem;
import de.jo.input.SimpleInputReceiverManager;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueBackward;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueDown;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueForward;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueLeft;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueRight;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueUp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 *
 * @author User
 */
public class SimpleSpatialItem extends SimpleMenuItem {

    private Spatial spatial;
    private DecimalFormat format = new DecimalFormat("0.000");

    {
        format.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
    }
    protected float manipulationMult = 0.125f;
    
    protected float moveSpeed = 5;

    public SimpleSpatialItem(String name, Spatial spatialIn) {
        super(name);
        this.spatial = spatialIn;


        this.addChild(new SimpleInputItem("Position: ") {
            @Override
            public void onValueAction(SimpleInputReceiverManager.SimpleInputReceiver.InputValue inputValue, float timeVal, float axisVal, boolean repeating) {
                if (spatial != null) {
                    Vector3f translation = new Vector3f();
                    Quaternion rotation = Quaternion.IDENTITY;
                    Vector3f scale = spatial.getLocalScale().clone();

                    switch (inputValue) {
                        case valueLeft:
                            translation.x = -moveSpeed * timeVal;
                            break;
                        case valueRight:
                            translation.x = moveSpeed * timeVal;
                            break;
                        case valueUp:
                            translation.y = moveSpeed * timeVal;
                            break;
                        case valueDown:
                            translation.y = -moveSpeed * timeVal;
                            break;
                        case valueForward:
                            translation.z = -moveSpeed * timeVal;
                            break;
                        case valueBackward:
                            translation.z = moveSpeed * timeVal;
                            break;
                    }
                    //System.out.println(" Bone User Transforms: "+ );
                    spatial.move(translation);
                }
            }

            @Override
            public String toString() {
                return name + "(" + format.format(spatial.getLocalTranslation().x) + "," + format.format(spatial.getLocalTranslation().y) + "," + format.format(spatial.getLocalTranslation().z) + ")"; //To change body of generated methods, choose Tools | Templates.
            }
        });
        SimpleMenuItem settings = new SimpleMenuItem("Settings");
        
        settings.addChild(new SimpleInputItem("MoveSpeed: ") {
            @Override
            public void onValueAction(SimpleInputReceiverManager.SimpleInputReceiver.InputValue inputValue, float timeVal, float axisVal, boolean repeating) {
               switch (inputValue) {
                        case valueInc:
                            moveSpeed = moveSpeed+ moveSpeed*manipulationMult;
                            break;
                        case valueDec:
                            moveSpeed = moveSpeed- moveSpeed*manipulationMult;
                            break;
                        
                    }  
            }

            @Override
            public String toString() {
                return name+moveSpeed; //To change body of generated methods, choose Tools | Templates.
            }
            
        });
        
        if(spatial instanceof Geometry){
        this.addChild(new SimpleGeometryItem("Geometry Properties", (Geometry)spatial));
        }
        
        this.addChild(settings);
    }
    
    
    
    
}
