/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item;

import de.jo.gui.menu.SimpleMenu;

/**
 *
 * @author jonas.reinhardt
 */
public abstract class TextMenuItem <T> extends SimpleMenuItem{

private SimpleMenu menu;
    
    
    public TextMenuItem(String name, SimpleMenu menu) {
        super(name);
        this.menu = menu;
    }
    
    
  public abstract String getValue();
  
  
 

  
  
  
  
     @Override
    public String toString() {
        return name +": "+getValue();
    }
}
