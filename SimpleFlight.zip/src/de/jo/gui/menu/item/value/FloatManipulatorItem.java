/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.value;

import de.jo.gui.menu.SimpleMenu;

/**
 *
 * @author jonas.reinhardt
 */
public abstract class FloatManipulatorItem extends NumberManipulatorItem<Float>{

    
   

    public FloatManipulatorItem( String name, SimpleMenu menu,float stepSize) {
        super(name, menu, stepSize);
        
    }
    
    
    
    @Override
    public void increase() {
       // System.out.println("increasing "+getValue()+" about "+stepSize+" : "+(getValue()+stepSize));
       setValue(getValue()+stepSize);
    }

    @Override
    public void decrease() {
        setValue(getValue()-stepSize); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
