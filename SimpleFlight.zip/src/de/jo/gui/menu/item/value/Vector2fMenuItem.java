/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.value;

import com.jme3.math.Vector2f;
import de.jo.gui.menu.SimpleMenu;
import de.jo.gui.menu.item.SimpleMenuItem;
import com.jme3.math.Vector3f;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;


/**
 *
 * @author jonas.reinhardt
 */
public abstract class Vector2fMenuItem extends SimpleMenuItem{
private DecimalFormat format = new DecimalFormat( "0.000" );
{
    format.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
//format.applyLocalizedPattern("en_US");
}
private SimpleMenu menu;
    
    
    public Vector2fMenuItem(String name, SimpleMenu menu) {
        super(name);
        this.menu = menu;
    }
    
    
  public abstract Vector2f getValue();
  
  
  public abstract void setValueIntern(Vector2f value);
  
  public void setValue(Vector2f value){
      
  setValueIntern(value);
  
  //this.menu.printMenu();
      
  }

     @Override
    public String toString() {
         Vector2f vec = getValue();
         
        return name +( vec != null ? ": ("+format.format(vec.x)+","+format.format(vec.y)+")" : "null");
    }
}
