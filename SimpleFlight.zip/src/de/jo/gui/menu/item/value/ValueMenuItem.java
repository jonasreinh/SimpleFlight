/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.value;

import de.jo.gui.menu.SimpleMenu;
import de.jo.gui.menu.item.SimpleMenuItem;

/**
 *
 * @author jonas.reinhardt
 */
public abstract class ValueMenuItem <T> extends SimpleMenuItem{

private SimpleMenu menu;
    
    
    public ValueMenuItem(String name, SimpleMenu menu) {
        super(name);
        this.menu = menu;
    }
    
    
  public abstract T getValue();
  
  
  public abstract void setValueIntern(T value);
  
  public void setValue(T value){
      
  setValueIntern(value);
  
  //this.menu.printMenu();
      
  }

  
  
  
  
     @Override
    public String toString() {
        return name +": "+getValue();
    }
}
