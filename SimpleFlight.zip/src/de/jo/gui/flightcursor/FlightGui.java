/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.flightcursor;

import com.jme3.asset.AssetManager;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Mesh;
import com.jme3.scene.Node;
import de.jo.gui.AxisViewController;
import de.jo.mesh.MeshUtil;
import de.jo.mesh.dynamic.DynamicGeometry;

/**
 *
 * @author jonas.reinhardt
 */
public class FlightGui extends Node {

    //private FlightCursorGeometry geometry;
   // private GuiController guiController;
    private float maxSteeringAmp = 100;
    private Vector2f steering = new Vector2f();
    private Geometry steeringReference;
    private Geometry steeringPointindicator;
    private Geometry yawIndicator;
    private float yawOffset = -2.5f;
    //private Vector3f steeringPoint = new Vector3f();
    private DynamicGeometry steeringAxisIndicators;

    
   // private DynamicGeometry axisIndicators;
    
    private DynamicGeometry  throttleAxisIndicator;
    private float scale = 60;
    
    
    public FlightGui() {
        //this.guiController = guiController;
    }

    public void init(AssetManager assetManager) {

        steeringReference = new Geometry("[Flight Cursor] Reference");

        steeringReference.setMesh(MeshUtil.createLineRing(32, scale, Vector3f.ZERO.clone()));
        steeringReference.getMesh().setLineWidth(1.5f);
        
        Material steeringMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        steeringMat.setColor("Color", ColorRGBA.White);
         
        steeringReference.setMaterial(steeringMat);
        steeringReference.updateModelBound();
        
        steeringPointindicator = new Geometry("[Flight Cursor] Steering Indicator");

        steeringPointindicator.setMesh(MeshUtil.createLineRing(16, 0.1f*scale, Vector3f.ZERO.clone()));
        steeringPointindicator.getMesh().setLineWidth(1);
       
        //Material cyan = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        //cyan.setColor("Color", ColorRGBA.White);
        //Material magenta = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        //magenta.setColor("Color", ColorRGBA.White);
        
        steeringPointindicator.setMaterial(steeringMat);
        steeringPointindicator.updateModelBound();
        
        
        yawIndicator = new Geometry("[Flight Cursor] Steering Indicator");
        float yawSize = 4f;
        yawIndicator.setMesh(MeshUtil.createLines(new Vector3f(-yawSize,-yawSize,0),new Vector3f(yawSize,yawSize,0),new Vector3f(-yawSize,yawSize,0),new Vector3f(yawSize,-yawSize,0)));//
        yawIndicator.getMesh().setLineWidth(1);
        yawIndicator.setMaterial(steeringMat);
        yawIndicator.updateModelBound();
        
        this.attachChild(steeringReference);
        this.attachChild(steeringPointindicator);
        this.attachChild(yawIndicator);
        steeringReference.setLocalTranslation(0, 0, 1000);
        
        Material yawAxisMat = assetManager.loadMaterial("Materials/VertexMaterial.j3m");//new Material(, "Common/MatDefs/Misc/Unshaded.j3md");
        //yawAxisMat.setBoolean("UseVertexColor",true);
       steeringAxisIndicators = new DynamicGeometry();
       steeringAxisIndicators.init(assetManager, yawAxisMat);
       steeringAxisIndicators.getDynamicMesh().setMode(Mesh.Mode.Lines);
       steeringAxisIndicators.getDynamicMesh().setLineWidth(2);
       steeringAxisIndicators.getDynamicMesh().addIndexdata(0,1,2,3,4,5);
       steeringAxisIndicators.getDynamicMesh().addVertexes(6);
       steeringAxisIndicators.getDynamicMesh().addColors(6);
       
       steeringAxisIndicators.createGeometry();
       steeringAxisIndicators.getDynamicMesh().setVertexColorData(0, 4, ColorRGBA.Red);
       steeringAxisIndicators.getDynamicMesh().setVertexColorData(4, 2, ColorRGBA.Blue);
       steeringAxisIndicators.getDynamicMesh().setVertexPositionData(4, new Vector3f(0,yawOffset,0));
       steeringAxisIndicators.getDynamicMesh().applyBuffers();
        
       this.attachChild(steeringAxisIndicators);

        
       throttleAxisIndicator = new DynamicGeometry();
       throttleAxisIndicator.init(assetManager, null);
       throttleAxisIndicator.getDynamicMesh().setMode(Mesh.Mode.Lines);
       throttleAxisIndicator.getDynamicMesh().setLineWidth(2);
       throttleAxisIndicator.getDynamicMesh().addIndexdata(0,1);
       throttleAxisIndicator.getDynamicMesh().addVertexes(2);
         
       throttleAxisIndicator.createGeometry();
        
       throttleAxisIndicator.setLocalTranslation(-100, -100, 0);
       
        this.attachChild(throttleAxisIndicator);
  
        
    }
    
  public void updateAxisDisplay(float roll, float pitch, float yaw, float throttle){
  //Vector3f indicatorPos = indicator.getLocalTranslation();
 /* steeringPoint.x = steeringPoint.x+x;
  steeringPoint.x = Math.abs(steeringPoint.x) > maxSteeringAmp ? Math.signum(steeringPoint.x)*maxSteeringAmp: steeringPoint.x;
  
  steeringPoint.y = steeringPoint.y+y;
  steeringPoint.y = Math.abs(steeringPoint.y) > maxSteeringAmp ? Math.signum(steeringPoint.y)*maxSteeringAmp: steeringPoint.y;*/
  
  /*float dist = steeringPoint.distance(Vector3f.ZERO);
  if (dist>maxSteeringAmp){
  float mult = maxSteeringAmp  /dist;  
  steeringPoint.multLocal(mult);
  }*/
  
   steeringPointindicator.setLocalTranslation(roll,pitch,0);
   yawIndicator.setLocalTranslation(yaw,yawOffset,0);
   
   steeringAxisIndicators.getDynamicMesh().setVertexPositionData(1, new Vector3f(roll,0,0));
   steeringAxisIndicators.getDynamicMesh().setVertexPositionData(3, new Vector3f(0,pitch,0));
   steeringAxisIndicators.getDynamicMesh().setVertexPositionData(5, new Vector3f(yaw,yawOffset,0));
   steeringAxisIndicators.getDynamicMesh().applyBuffers();
   
   
   throttleAxisIndicator.getDynamicMesh().setVertexPositionData(1, new Vector3f(0,throttle,0));
   throttleAxisIndicator.getDynamicMesh().applyBuffers();
   //indicator.setLocalTranslation(x, y, y);
      
  }  
    
    
}
