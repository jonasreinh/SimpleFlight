Prototyp f�r eine Flugsimulation mit Landschaftsdarstellung.

Tastenbelegung:

-- Kamera --

Maus bewegen 					: Kamera drehen
rechte Maustaste gedr�ckt halten + Maus bewegen : zoom


-- Flugsteuerung --

shift links : vortrieb erh�hen
strg links  : vortrieb verringern

A    	    : Rolle links
D	    : Rolle rechts
W	    : Nach oben neigen
S 	    : Nach unten neigen
Q	    : horizontal nach links drehen
E	    : horizontal nach rechts drehen


-- Men�steuerung (oben links in der Anwendung)-- 

 - Navigation -

Bild hoch    : n�chstes Men�element markieren (Das markierte Element wird in Klammern [] eingerahmt)
Bild runter  : vorheriges Men�element markieren
Backspace    : auf die n�chst h�here Ebene gelangen 
Eingabetaste : markiertes Men�element aktivieren ( Men�element mit drei vorangestellten Punkten ... enthalten eine tiefere Men�ebene)

 - �nderung von Werten - ( nur bei bestimmten Men�elementen m�glich, das entsprechende Men�element muss daf�r aktiviert werden)


Plus (Nummernblock)	      :  Wert um x erh�hen
Minus (Nummernblock)	      :  Wert um x verringern

Teilen (Nummernblock)	      : x durch zwei teilen	   

Multiplizieren (Nummernblock) : x mit zwei multiplizieren
