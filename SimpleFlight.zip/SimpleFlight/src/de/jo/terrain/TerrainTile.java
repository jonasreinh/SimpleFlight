/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.terrain;

import com.jme3.bounding.BoundingBox;
import com.jme3.math.FastMath;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Mesh;
import com.jme3.scene.VertexBuffer;
import com.jme3.scene.shape.Box;
import com.jme3.util.BufferUtils;
import de.jo.mesh.MeshUtil;
import de.jo.terrain.data.TerrainData;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

/**
 *
 * @author jonas.reinhardt
 */
public class TerrainTile extends Geometry {

    private FloatBuffer posBuffer;
    private FloatBuffer texCoordBuffer;
    private FloatBuffer normBuffer;
    private IntBuffer indexBuffer;
    
    public int lodIndex;
    private LodInfo lodInfo;
    public TileInfo visTileInfo;
    //private float[]heights = new float[5];
    private int parentTileX;
    private int parentTileZ;
    private Vector3f min;
    private Vector3f max;
    private int xBorder;
    private int zBorder;

    public TerrainTile(int lodIndex, LodInfo lodInfo, int xBorder, int zBorder) {
        this.lodIndex = lodIndex;
        this.lodInfo = lodInfo;
        this.xBorder = xBorder;
        this.zBorder = zBorder;
        
        init();
    }

    private int getTileVCount() {

        return (lodInfo.segmentCount + 1) * (lodInfo.segmentCount + 1);
    }

    private void init2() {
        //Mesh m = new Box(Vector3f.ZERO,new Vector3f(lodInfo.segmentCount *lodInfo.segmentSize,lodInfo.segmentCount *segmentSize*0.1f,lodInfo.segmentCount *segmentSize));    
        //this.setMesh(m);
    }

    private void init() {
        float segmentSize = lodInfo.getVisualSegmentSize(lodIndex);
        posBuffer = BufferUtils.createFloatBuffer(3 * getTileVCount());
        normBuffer = BufferUtils.createFloatBuffer(3 * getTileVCount());
        texCoordBuffer = BufferUtils.createFloatBuffer(2 * getTileVCount());
        indexBuffer = BufferUtils.createIntBuffer((lodInfo.segmentCount + 1) * (lodInfo.segmentCount + 1) * 6);
        
        MeshUtil.createPolyGrid(posBuffer, indexBuffer, texCoordBuffer,0.125f, 0, lodInfo.segmentCount, lodInfo.segmentCount, segmentSize,Vector3f.ZERO);
        MeshUtil.adaptTerrainIndexesToBorder(indexBuffer,lodInfo.segmentCount, lodInfo.segmentCount, this.xBorder, this.zBorder, 0, 0);
       // this.xBorder, this.zBorder,
        
        normBuffer.position(0);
        for (int i = 0; i < normBuffer.capacity() / 3; i++) {
            normBuffer.put(0).put(1).put(0);

        }

        Mesh m = new Mesh();
       
        m.setMode(Mesh.Mode.Triangles);
        m.setBuffer(VertexBuffer.Type.Position, 3, posBuffer);
        m.setBuffer(VertexBuffer.Type.Normal, 3, normBuffer);
        m.setBuffer(VertexBuffer.Type.TexCoord, 2, texCoordBuffer);
        m.scaleTextureCoordinates(new Vector2f(0.125f, 0.125f));
        m.setBuffer(VertexBuffer.Type.Index, 3, indexBuffer);

        this.min = new Vector3f(0, 0, 0);
        this.max = new Vector3f(lodInfo.segmentCount * segmentSize, 1, lodInfo.segmentCount * segmentSize);
        BoundingBox bb = new BoundingBox(min, max);
        m.setBound(bb);
        this.setMesh(m);
        //this.updateGeometricState();
    }

 
    
    public void updateBorders(TerrainData terrainData,int newXBorder, int newZBorder){
     if(newXBorder!=this.xBorder || newZBorder!=this.zBorder){
         //System.out.println("UpdateBorders old:("+xBorder+","+zBorder+") new: ("+newXBorder+","+newZBorder+")");
          MeshUtil.adaptTerrainIndexesToBorder(indexBuffer,lodInfo.segmentCount, lodInfo.segmentCount, newXBorder, newZBorder,this.xBorder,this.zBorder); 
          this.getMesh().getBuffer(VertexBuffer.Type.Index).updateData(indexBuffer);
          if(terrainData!=null){
          this.updateTerrainBorderData(terrainData, newXBorder, newZBorder);}
          
          this.xBorder = newXBorder;
          this.zBorder = newZBorder;
          
          
     }   
    
        
        
    }

    public void updateTerrainBorderData(TerrainData terrainData,int newXBorder, int newZBorder) {

        float segmentSize = lodInfo.getVisualSegmentSize(lodIndex);

        Vector3f vPos = new Vector3f();

       

        Vector3f normCurrent = new Vector3f();
        Vector3f normParent = new Vector3f();
        Vector3f norm = new Vector3f();

       
        int lod = terrainData.getLodForResolutionSize(lodInfo.getVisualResolutionSize(lodIndex) );
        int parentLod = terrainData.getLodForResolutionSize(lodInfo.getVisualResolutionSize(lodIndex + 1) );
        
        int fadeSegments = getFadeSegments(0.5f, lodInfo.segmentCount);
        
        float linearity = 0.5f;

        
        boolean xBCh = newXBorder != this.xBorder;
        boolean zBCh = newZBorder != this.zBorder;

        boolean zBHCh = zBCh && (newZBorder == 1 || this.zBorder == 1);
        boolean zBLCh = zBCh && (newZBorder == -1 || this.zBorder == -1);

        boolean xBHCh = xBCh && (newXBorder == 1 || this.xBorder == 1);
        boolean xBLCh = xBCh && (newXBorder == -1 || this.xBorder == -1);

        int zStart = xBCh || zBLCh  ? 0 : lodInfo.segmentCount - fadeSegments;
        int zEnd   = xBCh ||  zBHCh ? lodInfo.segmentCount : fadeSegments;      
        
        for (int z = zStart; z <= zEnd; z++) {
            
            int fadeIndexZ = newZBorder == 0 ? fadeSegments : (newZBorder == -1 ? z : lodInfo.segmentCount - z);
            
            int xStart = ((z <= fadeSegments && zBLCh) || (z >= lodInfo.segmentCount - fadeSegments && zBHCh)) || xBLCh ? 0 : lodInfo.segmentCount - fadeSegments;
            int xEnd = ((z <= fadeSegments && zBLCh) || (z >= lodInfo.segmentCount - fadeSegments && zBHCh)) || xBHCh ? lodInfo.segmentCount  : fadeSegments;
            int xInc = (zBLCh&&z<=1)||(zBLCh&&z>=lodInfo.segmentCount-1)? 1 : lodInfo.segmentCount-2;
            for (int x = xStart; x <= xEnd; x += 1) {//(xBLCh&&x==0)||(xBHCh&&x==lodInfo.segmentCount-1) ? 1:xInc
                //Vector3f mid = guiController.getMiddlePos();
                if(!MeshUtil.isSkipTerrainGridPos(x, z, lodInfo.segmentCount, lodInfo.segmentCount, newXBorder, newZBorder)){

                int fadeIndexX = newXBorder == 0 ? fadeSegments : (newXBorder == -1 ? x : lodInfo.segmentCount - x);//zBorder==0 ? xBorder==0 ?0 : (xBorder==-1 ?  x : segmentCount-x ):(zBorder==-1 ?  z : segmentCount-z );
                int fadeIndex = fadeIndexX < fadeIndexZ ? fadeIndexX : fadeIndexZ;

                

                float fadeVal = fadeIndex <= 0 ? 1 : fadeIndex < fadeSegments ? ((1f-linearity)*((FastMath.cos(FastMath.PI*(fadeIndex/((float)fadeSegments)))+1f)/2f)+linearity*(1f-(fadeIndex/(float)fadeSegments))) : 0;
                float fadeValInv = 1f - fadeVal;

                float h;

                if (fadeVal == 0) {//
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, norm, terrainData, lod, segmentSize);
                    h = vPos.y;

                } else if (fadeVal == 1) {
    
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, norm, terrainData, parentLod, segmentSize);
                    h = vPos.y;

                } else {
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, normCurrent, terrainData, lod, segmentSize);

                    h = fadeValInv * vPos.y;
                    
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, normParent, terrainData, parentLod, segmentSize);
                    h += fadeVal * vPos.y;
                    norm.x = fadeValInv * normCurrent.x + fadeVal * normParent.x;
                    norm.y = fadeValInv * normCurrent.y + fadeVal * normParent.y;
                    norm.z = fadeValInv * normCurrent.z + fadeVal * normParent.z;
                    norm.normalizeLocal();
                }

                int index = 3* MeshUtil.getTerrainGridIndex(x, z, lodInfo.segmentCount) ;
                
                posBuffer.position(index  + 1); // + 1 = Vertex Y (Height)
                posBuffer.put(h);
                normBuffer.position(index);
                normBuffer.put(norm.x).put(norm.y).put(norm.z);}

            }
        }

        this.getMesh().getBuffer(VertexBuffer.Type.Position).updateData(posBuffer);
        this.getMesh().getBuffer(VertexBuffer.Type.Normal).updateData(normBuffer);

    }
    
    public void loadTerrainData(TerrainData terrainData) {
        float segmentSize = lodInfo.getVisualSegmentSize(lodIndex);
        float parentSegmentSize = lodInfo.getVisualSegmentSize(lodIndex + 1);
        int vCount = getTileVCount();
        Vector3f vPos = new Vector3f();
        Vector3f vPosParent = new Vector3f();


        posBuffer.position(0);
        normBuffer.position(0);
        //float[] heights = new float[5];
        Vector3f normCurrent = new Vector3f();
        Vector3f normParent = new Vector3f();
        Vector3f norm = new Vector3f();

        //int dataLod = (int) terrainData.getDataSetup().getLodForSegmentSize(segmentSize);
        int lod = terrainData.getLodForResolutionSize(lodInfo.getVisualResolutionSize(lodIndex) );
        int parentLod = terrainData.getLodForResolutionSize(lodInfo.getVisualResolutionSize(lodIndex + 1) );

        float minHeight = Float.MAX_VALUE;
        float maxHeight = -Float.MAX_VALUE;

        //float fadePow = -1;
       // if (xBorder != 0 || zBorder != 0) {
        //    fadePow = getFadePow(0.5f, 0.5f, lodInfo.segmentCount);
       // }
        int fadeSegments = getFadeSegments(0.5f, lodInfo.segmentCount);
        
        float linearity = 0.5f;
        /*for(int i = 0; i<fadeSegments;i++){
            System.out.println("fadeVal["+i+"]: "+((1f-linearity)*((FastMath.cos(FastMath.PI*(i/((float)fadeSegments)))+1f)/2f)+linearity*(1f-(i/(float)fadeSegments))));
        }*/
        //long time0 = System.currentTimeMillis();
        //for(int runs = 0; runs<1000; runs++){
        for (int z = 0; z < lodInfo.segmentCount + 1; z++) {
            int fadeIndexZ = zBorder == 0 ? fadeSegments : (zBorder == -1 ? z : lodInfo.segmentCount - z);
            for (int x = 0; x < lodInfo.segmentCount + 1; x++) {
                //Vector3f mid = guiController.getMiddlePos();
                if(!MeshUtil.isSkipTerrainGridPos(x, z, lodInfo.segmentCount, lodInfo.segmentCount, xBorder, zBorder)){

                int fadeIndexX = xBorder == 0 ? fadeSegments : (xBorder == -1 ? x : lodInfo.segmentCount - x);//zBorder==0 ? xBorder==0 ?0 : (xBorder==-1 ?  x : segmentCount-x ):(zBorder==-1 ?  z : segmentCount-z );
                int fadeIndex = fadeIndexX < fadeIndexZ ? fadeIndexX : fadeIndexZ;

                

                float fadeVal = fadeIndex <= 0 ? 1 : fadeIndex < fadeSegments ? ((1f-linearity)*((FastMath.cos(FastMath.PI*(fadeIndex/((float)fadeSegments)))+1f)/2f)+linearity*(1f-(fadeIndex/(float)fadeSegments))) : 0;
                float fadeValInv = 1f - fadeVal;

                float h;

                if (fadeVal == 0) {//
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, norm, terrainData, lod, segmentSize);
                    h = vPos.y;

                } else if (fadeVal == 1) {
    
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, norm, terrainData, parentLod, segmentSize);
                    h = vPos.y;

                } else {
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, normCurrent, terrainData, lod, segmentSize);

                    h = fadeValInv * vPos.y;
                    
                    vPos.x = visTileInfo.posX + x * segmentSize;
                    vPos.z = visTileInfo.posZ + z * segmentSize;
                    getHeightAndNorm(vPos, normParent, terrainData, parentLod, segmentSize);
                    h += fadeVal * vPos.y;
                    norm.x = fadeValInv * normCurrent.x + fadeVal * normParent.x;
                    norm.y = fadeValInv * normCurrent.y + fadeVal * normParent.y;
                    norm.z = fadeValInv * normCurrent.z + fadeVal * normParent.z;
                    norm.normalizeLocal();
                }
                
                if(h<minHeight){
                   minHeight = h;
                }
                if(h>maxHeight){
                   maxHeight = h;
                }
                
                int index = 3* MeshUtil.getTerrainGridIndex(x, z, lodInfo.segmentCount) ;
                
                
                posBuffer.position(index  + 1); // + 1 = Vertex Y (Height)
                posBuffer.put(h);
                normBuffer.position(index);
                normBuffer.put(norm.x).put(norm.y).put(norm.z);}

            }
        }
        //}
        
        
        //long time1 = System.currentTimeMillis();
       // System.out.println("time: "+(time1-time0)+" counter: "+counter);
        //counter+=1;

        this.getMesh().setBuffer(VertexBuffer.Type.Position, 3, posBuffer);
        this.getMesh().setBuffer(VertexBuffer.Type.Normal, 3, normBuffer);

        min.y = minHeight;
        max.y = maxHeight;

        //System.out.println("minHeight: "+minHeight+" maxHeight: "+maxHeight);
        // this.getMesh().setBound(new BoundingBox(min.clone(), max.clone()));
        ((BoundingBox) this.getMesh().getBound()).setMinMax(min, max);

        /*  Vector3f min2 = new Vector3f();
         Vector3f max2 = new Vector3f();
         ((BoundingBox) this.getMesh().getBound()).getMin(min2);
         ((BoundingBox) this.getMesh().getBound()).getMax(max2);
         System.out.println("Tile Bound: ["+min2+" - "+max2+"] ");*/
        //this.updateModelBound();
        //this.updateGeometricState();
    }

    public static float getFadePow(float fadeRangeToTileSize, float lastFadeValMult, int segments) {
        int fadeSegments = getFadeSegments(fadeRangeToTileSize, segments);
        float linearLastFadeVal = 1f / fadeSegments;
        return fadeSegments > 1 ? FastMath.log(linearLastFadeVal * lastFadeValMult, 2) / (fadeSegments - 1) : 1;
    }

    public static int getFadeSegments(float fadeRangeToTileSize, int segments) {
        return (int) (segments * fadeRangeToTileSize) + 1;
    }

    private void getHeightAndNorm(Vector3f vPos, Vector3f norm, TerrainData terrainData, int datalod, float segmentSize) {

        float h = terrainData.getVal(datalod, vPos.x, vPos.z);
        float hxL = terrainData.getVal(datalod, vPos.x - 1 * segmentSize, vPos.z);
        float hxH = terrainData.getVal(datalod, vPos.x + 1 * segmentSize, vPos.z);
        float hzL = terrainData.getVal(datalod, vPos.x, vPos.z - 1 * segmentSize);
        float hzH = terrainData.getVal(datalod, vPos.x, vPos.z + 1 * segmentSize);
        vPos.y = h;
        norm.x = hxH - hxL;
        norm.y = 2 * segmentSize;
        norm.z = hzH - hzL;
        norm.normalizeLocal();
    }
    
    
private static int counter = 0;    
    
}
