/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.terrain.data;

import com.jme3.math.FastMath;



/**
 *
 * @author jonas.reinhardt
 */
public class TerrainData {

private int lodLevels;
private int featureBaseSize;
private int sizeShiftPerLod;
private float heightLodFactor = 0.7f;
private float heightBaseFactor = 0.5f;

private OpenSimplexNoise[] noiseFunctions;

    public TerrainData(int lodLevels, int featureBaseSize, int sizeShiftPerLod) {
        this.lodLevels = lodLevels;
        this.featureBaseSize = featureBaseSize;
        this.sizeShiftPerLod = sizeShiftPerLod;
        
        noiseFunctions = new OpenSimplexNoise[lodLevels];
        for (int i = 0; i < lodLevels; i++) {
          noiseFunctions[i] = new OpenSimplexNoise((i+19)*641);
        }
        
    }

    public float getVal(int lod, float x, float z){
        
        float heightPreLevelFalloff = 0.4f;
        
        float val = 0;
         //System.out.println("lod: "+lod+" lodLevels: "+lodLevels);
        float featureSize;
        float lodHeightMult;
        float hMult = 1;
        for (int lodIndex = lodLevels-1; lodIndex >= lod; lodIndex--) {
            
            featureSize = getLodFeatureSize(lodIndex);
            lodHeightMult = featureSize*(heightBaseFactor*FastMath.pow(heightLodFactor, lodIndex));
            double noiseH = noiseFunctions[lodIndex].eval((double)x / featureSize, z / featureSize);
            //System.out.println("vl: "+noiseFunctions[lodIndex].eval((double)x / featureSize, z / featureSize));
            val+=  hMult*lodHeightMult*noiseH;
           //System.out.println("lod: "+lod+" lodIndex: "+lodIndex+" featureSize: "+featureSize+" val: "+val);
            hMult = (float)(noiseH*(1f-heightPreLevelFalloff+ heightPreLevelFalloff*((noiseH+1f)/2f)));
        }
         //System.out.println("resultVal: "+val);
        return val;
        
    }
    
    public int getLodFeatureSize(int lod){
        
        return featureBaseSize << (sizeShiftPerLod * lod);
    }
    
    public int getLodForResolutionSize(float resolutionSize){
        
        double res = ((Math.log((resolutionSize*8)/(float)featureBaseSize) / Math.log(2))/(float)sizeShiftPerLod);
        return res > 0 ? (res <= lodLevels-1 ? (int)res: lodLevels-1) : 0;
    }



}
