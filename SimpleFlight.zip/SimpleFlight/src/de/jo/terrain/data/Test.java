/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.terrain.data;

/**
 *
 * @author User
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here


        int areas = 100;

        float[] occurances = new float[areas];
        

        int testAreaSize = 10000;

        OpenSimplexNoise osNoise = new OpenSimplexNoise(System.currentTimeMillis());
        
        
        int count = 0;
        
        long time0 = System.currentTimeMillis();
        
        long time1 = System.currentTimeMillis();
        
        System.out.println("Time: "+(time1-time0));
        for(int i = 0; i < occurances.length; i++){
            System.out.println("NoiseOcurrances Value ("+((float)i/areas)+" - "+((float)(i+1)/areas)+"): "+(100*occurances[i]/(float)count)+"%");
        }

    }
    
    
 /*private static void test1(){
     
 for (int z = -testAreaSize / 2; z < testAreaSize / 2; z++) {
            for (int x = -testAreaSize / 2; x < testAreaSize / 2; x++) {
                
             float noiseVal =Noise.noise(x, z);
             if(noiseVal<0){
             }
             if(noiseVal == 1.0 ){
                occurances[areas-1] += 1; 
             }else{
                 occurances[(int)(noiseVal*areas)] += 1;
             }

             count ++;
            }
        }    
     
 }   */
    
}
