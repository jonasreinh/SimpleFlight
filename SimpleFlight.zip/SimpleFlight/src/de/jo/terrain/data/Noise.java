/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.terrain.data;

/**
 *
 * @author jonas.reinhardt
 */
public class Noise {

    public static float noise2(int x, int y) {
        int n = x * x + y * y * 57;
        n = (n << 13) ^ n;//;
        float val = 0.5f * (((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f);
//System.out.println("noise: "+val);
        return val;
    }
    
    
    
    public static float noise(int x, int y) {
        int n = x* 15731;
        
        n ^= 0xE56FAA12;
        
        n += y * 789221;
        
        n ^= 0x69628a2d;
        
        //n = (n << 13) ^ n;//;
        float val = 0.5f+((int)n%2001)/4000f;
//System.out.println("noise: "+val);
        return val;
    }
}
