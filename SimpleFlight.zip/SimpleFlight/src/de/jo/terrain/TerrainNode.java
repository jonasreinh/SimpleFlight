/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.terrain;

import de.jo.terrain.data.TerrainData;
import com.jme3.app.SimpleApplication;
import com.jme3.bounding.BoundingBox;
import com.jme3.bullet.PhysicsSpace;
//import com.jme3.bullet.PhysicsSpace;
import com.jme3.material.Material;
import com.jme3.material.RenderState;
import com.jme3.math.ColorRGBA;
import com.jme3.math.FastMath;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.texture.Texture;
import de.jo.mesh.MeshUtil;
import de.jo.mesh.dynamic.SimilarObjectContainerMesh;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author jonas.reinhardt
 */
public class TerrainNode extends Node {

    private Material groundMaterial;
    private TerrainData heightData;
    private LodInfo lodInfo;
    private Map<TileInfo, TerrainTile> usedTilesMap = new TreeMap<TileInfo, TerrainTile>();
    //private Map<TileInfo, TerrainTile> tilesToAddMap[] = new TreeMap<TileInfo, TerrainTile>();
    //private Set<TerrainTile>[] lodTiles;
    //private Map<TileInfo, TerrainTile>[] unusedTilesMap = new Map[lodLevels];
    public int maxTileDist;// = 4;
    private float minLodUpdateDistVSTileSize = 0.25f;
    private Vector3f lastUpdateCamPos = new Vector3f(Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE);
    private Vector3f[] lodLastUpdatePos;
    private TreeSet<TileInfo> tilesRemove = new TreeSet<TileInfo>();
    private TreeSet<TileInfo> tilesAdd = new TreeSet<TileInfo>();
    private TreeSet<TileInfo> currentVisibleTiles = new TreeSet<TileInfo>();
    private Queue<TerrainTile>[] unusedTiles;
    private TerrainTileContainerMesh tileBoundingsMesh;
    private Geometry tileBoundingGeom;
    private Material debugMaterial;
    private TileInfo[][] lodTileMinMax;

    public TerrainNode(LodInfo lodInfo, int maxTileDist) {
        this.maxTileDist = maxTileDist;
        this.lodInfo = lodInfo;
        
        this.unusedTiles = new Queue[lodInfo.lodLevels];
        for(int i = 0; i<unusedTiles.length;i++){
           this.unusedTiles[i] = new LinkedList<>(); 
        }
        /*this.segmentCount = segmentCount;
        this.segmentBaseSize = segmentBaseSize;
        this.lodLevels = lodLevels;
        this.maxTileDist = maxTileDist;*/
        lodLastUpdatePos = new Vector3f[lodInfo.lodLevels];
        //lodTiles = new Set[lodLevels];
        lodTileMinMax = new TileInfo[lodInfo.lodLevels][];
        for (int i = 0; i < lodInfo.lodLevels; i++) {
            lodLastUpdatePos[i] = lastUpdateCamPos.clone();
            lodTileMinMax[i] = new TileInfo[]{new TileInfo(i, 0, 0),new TileInfo(i, 0, 0)};
            //lodTiles[i] = new TreeSet<TerrainTile>();
        }
        
        
        
        tileBoundingsMesh = new TerrainTileContainerMesh(8, 12, 0);
        tileBoundingsMesh.setPointSize(4);

    }

    public void init(SimpleApplication simpleApplication, PhysicsSpace physicsSpace) {

        groundMaterial = simpleApplication.getAssetManager().loadMaterial("Materials/TerrainMat.j3m");//new Material(, "MatDefs/InfTerrain.j3md");//simpleApplication.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        //groundMaterial.setBoolean("VERTEX_LIGHTING", true);
        Texture grass = simpleApplication.getAssetManager().loadTexture("Textures/Terrain/splat/grass.jpg");
        grass.setWrap(Texture.WrapMode.Repeat);
        groundMaterial.setTexture("DiffuseMap", grass);

        
        debugMaterial = new Material(simpleApplication.getAssetManager(), "MatDefs/InfUnsh.j3md");
        //debugMaterial.setColor("Color", ColorRGBA.Blue);
        debugMaterial.setBoolean("VertexColor", true);
        
        tileBoundingGeom = new Geometry("TileBoundingGeom", tileBoundingsMesh);
        tileBoundingGeom.setMaterial(debugMaterial);

        //this.attachChild(tileBoundingGeom);
    }

    public Material getDebugMaterial() {
        return debugMaterial;
    }

    
    
    public TerrainData getHeightData() {
        return heightData;
    }

    public void setHeightData(TerrainData heightData) {
        this.heightData = heightData;
    }

    public void updateTilesForPosition(Vector3f position) {
        long time0 = System.currentTimeMillis();
        Vector3f camPos = position.clone();
        Vector3f lodPos = new Vector3f();
        Vector3f lodVecToLastUpdate = new Vector3f();

        getLodPos(0, camPos, lodPos);

        if (lodPos.distanceSquared(lodLastUpdatePos[0]) > 0 && camPos.distance(lastUpdateCamPos) > minLodUpdateDistVSTileSize * lodInfo.getVisualTileSize(0)) {
            
            boolean lodChanged = false;
            for (int lodIndex = lodInfo.lodLevels - 1; lodIndex >= 0; lodIndex--) {
                
                getLodPos(lodIndex, camPos, lodPos);
                lodPos.subtract(lodLastUpdatePos[lodIndex], lodVecToLastUpdate);
                float tileSize = lodInfo.getVisualTileSize(lodIndex);
                lodTileMinMax[lodIndex][0].posX = Float.MAX_VALUE;
                lodTileMinMax[lodIndex][0].posZ = Float.MAX_VALUE;
                lodTileMinMax[lodIndex][1].posX = -Float.MAX_VALUE;
                lodTileMinMax[lodIndex][1].posZ = -Float.MAX_VALUE;
                
                for (int z = -maxTileDist; z < maxTileDist; z++) {
                    for (int x = -maxTileDist; x < maxTileDist; x++) {
                        //Vector3f tilePosition = new Vector3f(,0,);   

                        TileInfo ti = new TileInfo();
                        ti.posX = (x + lodPos.x) * tileSize;
                        ti.posZ = (z + lodPos.z) * tileSize;
                        ti.lod = lodIndex;
                        tilesAdd.add(ti);
                        if (lodIndex < lodInfo.lodLevels - 1) {
                            tilesRemove.add(getParentTile(ti));
                        }
                        
                       /* if(ti.posX<lodTileMinMax[lodIndex][0].posX){
                         lodTileMinMax[lodIndex][0].posX = ti.posX;   
                        }
                        if(ti.posZ<lodTileMinMax[lodIndex][0].posZ){
                         lodTileMinMax[lodIndex][0].posZ = ti.posZ;   
                        }
                        
                        if(ti.posX>lodTileMinMax[lodIndex][0].posX){
                         lodTileMinMax[lodIndex][1].posX = ti.posX;   
                        }
                        if(ti.posZ>lodTileMinMax[lodIndex][0].posZ){
                         lodTileMinMax[lodIndex][1].posZ = ti.posZ;   
                        }*/
                    }
                }
                
                if (lodVecToLastUpdate.lengthSquared() > 0) {

                    lodChanged = true;
                    lodLastUpdatePos[lodIndex].set(lodPos);
                }
            }
            if (lodChanged) {
                int factor = 1 << lodInfo.segmentSizeShiftPerLod;
                TileInfo tiChild = new TileInfo();
                for (TileInfo ti : tilesRemove) {
                    tilesAdd.remove(ti);
                    if (ti.lod > 0) {
                        tiChild.lod = ti.lod - 1;
                        int childTileSize = lodInfo.getVisualTileSize(tiChild.lod);
                        for (int z = 0; z < factor; z++) {
                            tiChild.posZ = ti.posZ + z * childTileSize;
                            for (int x = 0; x < factor; x++) {
                                tiChild.posX = ti.posX + x * childTileSize;
                                if (!tilesAdd.contains(tiChild)) {
                                    tilesAdd.add(tiChild.clone());
                                }
                            }
                            if (currentVisibleTiles.contains(ti)) {
                                hideTile(ti);
                            }
                        }
                    }
                }

                tilesRemove.clear();
                tilesRemove.addAll(currentVisibleTiles);
                
                
                for(TileInfo ti : tilesAdd){
                    
                   
                    if(ti.posX<lodTileMinMax[ti.lod][0].posX){
                         lodTileMinMax[ti.lod][0].posX = ti.posX;   
                        }
                        if(ti.posZ<lodTileMinMax[ti.lod][0].posZ){
                         lodTileMinMax[ti.lod][0].posZ = ti.posZ;   
                        }
                        
                        if(ti.posX>lodTileMinMax[ti.lod][1].posX){
                         lodTileMinMax[ti.lod][1].posX = ti.posX;   
                        }
                        if(ti.posZ>lodTileMinMax[ti.lod][1].posZ){
                         lodTileMinMax[ti.lod][1].posZ = ti.posZ;   
                        }
                }
                
                
                

                for (TileInfo ti : tilesAdd) {
                   
                        showTile(ti, time0);
                    
                  
                }

                tilesAdd.clear();

                for (TileInfo ti : tilesRemove) {
                    // if(ti.lod<=highestUpdatedLevel){
                    hideTile(ti);
                }
                tilesRemove.clear();

                /*for (Entry<TileInfo, TerrainTile> entry : usedTilesMap.entrySet()) {
                    TileInfo ti = entry.getKey();
                    System.out.println("TileInfo: " + entry.getKey());
                    if(ti.lod<lodLevels-1){
                        
                    }
                }*/
            }

            this.tileBoundingsMesh.updateBuffers();
            tileBoundingGeom.updateGeometricState();
            tileBoundingGeom.updateModelBound();

            this.lastUpdateCamPos = camPos;

            long time1 = System.currentTimeMillis();

            System.out.println("Terrain update Time: " + (time1 - time0));
        }

    }

    private void getLodPos(int lodIndex, Vector3f camPos, Vector3f store) {

        int tileSize = lodInfo.getVisualTileSize(lodIndex);
        store.x = FastMath.floor((camPos.x / tileSize));
        store.y = FastMath.floor((camPos.y / tileSize));
        store.z = FastMath.floor((camPos.z / tileSize));
    }

    /*private void hideLodOutdatedTiles(int visLod, long timeKey) {
     for (TerrainTile tile : this.lodTiles[visLod]) {
     if (tile.lastUpdateTime < timeKey) {
     hideTile(tile);
     }
     }
     }*/
    private void showTile(TileInfo ti, long timeKey) {

        TerrainTile tile = usedTilesMap.get(ti);
        int xBorder = lodTileMinMax[ti.lod][0].posX == ti.posX ? -1 : lodTileMinMax[ti.lod][1].posX == ti.posX ? 1:0;
        int zBorder = lodTileMinMax[ti.lod][0].posZ == ti.posZ ? -1 : lodTileMinMax[ti.lod][1].posZ == ti.posZ ? 1:0;
        if (tile == null) {    
        //System.out.println("xBorder: "+xBorder+" zBorder: "+zBorder);
        tile = prepareNewTile(ti.lod, xBorder,zBorder);
        tile.visTileInfo = ti;
        tile.setMaterial(groundMaterial);
        tile.loadTerrainData(heightData);
        tile.getLocalTranslation().set(ti.posX, 0, ti.posZ);  
        
        this.attachChild(tile);
        this.usedTilesMap.put(ti, tile);   
        this.currentVisibleTiles.add(ti);
            tileBoundingsMesh.addTile(tile,ti);
        }else{
          tile.updateBorders(heightData,xBorder, zBorder);
            tilesRemove.remove(ti);  
        }
       
    }
    
    private TerrainTile prepareNewTile(int lodLevel,int xBorder, int zBorder){
         TerrainTile t;
    if(!unusedTiles[lodLevel].isEmpty()){
     t= unusedTiles[lodLevel].poll();
     t.lodIndex = lodLevel;
     t.updateBorders(null, xBorder, zBorder);
    }else{
      t = new TerrainTile(lodLevel, lodInfo,xBorder,zBorder);
      //System.out.println("TileCreated");
        
    }    
        return t;
    }

    private void hideTile(TileInfo ti) {

        TerrainTile tile = this.usedTilesMap.get(ti);

        this.usedTilesMap.remove(ti);
        this.currentVisibleTiles.remove(ti);
        
        //this.lodTiles[ti.lod].remove(tile);
        this.detachChild(tile);
        tileBoundingsMesh.removeTile(tile);
        this.unusedTiles[ti.lod].add(tile);
    }

    /*private void hideTile(TerrainTile tile) {

        this.usedTilesMap.remove(tile.visTileInfo);
        this.currentVisibleTiles.remove(tile);
        // this.lodTiles[tile.visTileInfo.lod].remove(tile);
        this.detachChild(tile);

    }*/

    

    public Material getGroundMaterial() {
        return groundMaterial;
    }

    private TileInfo getParentTile(TileInfo ti) {

        TileInfo tiParent = new TileInfo();
        int parentTileSize = lodInfo.getVisualTileSize(ti.lod + 1);
        tiParent.lod = ti.lod + 1;
        tiParent.posX = ((int) Math.floor(ti.posX / parentTileSize)) * parentTileSize;
        tiParent.posZ = ((int) Math.floor(ti.posZ / parentTileSize)) * parentTileSize;

        //System.out.println("Parent Tile of " + ti + " -> " + tiParent);
        return tiParent;
    }

    

    private class TerrainTileContainerMesh extends SimilarObjectContainerMesh {

        public TerrainTileContainerMesh(int objectVertexCount, int objectIndexCount, int maxObjectCount) {
            super(objectVertexCount, objectIndexCount, maxObjectCount, 2,Mode.Hybrid.Lines);
            
            
        }
        private Map<TerrainTile, Integer> tileIndexMap = new HashMap<TerrainTile, Integer>();

        public void addTile(TerrainTile tile,TileInfo ti) {
            
            
            attachChild(tile);
            int tileIndex = super.addObject();
            tileIndexMap.put(tile, tileIndex);
            Vector3f position = new Vector3f();
            Vector3f size = new Vector3f();
            
            ((BoundingBox) tile.getMesh().getBound()).getMin(position);
            ((BoundingBox) tile.getMesh().getBound()).getMax(size);
  
            size.subtractLocal(position);
            position.addLocal(tile.getLocalTranslation());
           //System.out.println("Bound: position: "+position+" size: "+size);
            
            MeshUtil.createLineBox(positionBuffer, indexBuffer, tileIndex * objectVertexCount, tileIndex * objectIndexCount, position, size);
             ColorRGBA color = new ColorRGBA(1f-(ti.lod%3/2f), 1f-(ti.lod%7/6f),1f-(ti.lod%13/12f) , 1f);
            super.fillObjectColor(tileIndex, color);
        }

        public void removeTile(TerrainTile tile) {

            int tileIndex = tileIndexMap.get(tile);
            tileIndexMap.remove(tile);

            super.removeObject(tileIndex);

        }
    }
}
