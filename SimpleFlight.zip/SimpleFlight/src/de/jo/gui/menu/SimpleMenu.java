/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu;

import de.jo.gui.menu.item.SimpleMenuItem;
import de.jo.math.JoMath;

/**
 *
 * @author jonas.reinhardt
 */
public class SimpleMenu {

    
    private int pageSize;
    private int currentPage = 0;
    protected SimpleMenuItem rootItem = new SimpleMenuItem("Menu");
    protected SimpleMenuItem parentItem = rootItem;
    protected SimpleMenuItem markedItem = null;
    protected SimpleMenuItem lastActivatedItem = null;

    public SimpleMenu(int pageSize) {
        this.pageSize = pageSize;
    }

    public void addMenuItem( SimpleMenuItem menuItem) {

       addMenuItem(null, menuItem);
    }
    
    public void addMenuItem(String[] path, SimpleMenuItem menuItem) {

        SimpleMenuItem parItem = findChildItem(path, rootItem);

        System.out.println("MenuParentItem found: " + parItem);
        parItem.addChild(menuItem);
    }

    public SimpleMenuItem findChildItem(String[] path, SimpleMenuItem menuItem) {

        if (path == null || path.length == 0) {
            return menuItem;
        }


        for (SimpleMenuItem childItem : menuItem.getChildren()) {
            // System.out.println("searching for '" + path[0] + "' in  '" + childItem + "'");
            if (childItem.getName().equals(path[0])) {

                if (path.length > 1) {
                    String[] nextPath = new String[path.length - 1];

                    for (int i = 1; i < path.length; i++) {
                        nextPath[i - 1] = path[i];
                    }
                    return findChildItem(nextPath, childItem);
                } else {
                    return childItem;
                }
            }
        }

        throw new UnsupportedOperationException("'" + path[0] + "' not found in menuItem '" + menuItem + "' " + menuItem.getChildren());
    }

    public void moveCursor(int amount) {
        lastActivatedItem = null;
        if(this.markedItem!=null){
        this.markedItem.onDeactivate();
        
        }
        if (this.parentItem.getChildCount() > 0) {
            int markedIndex = 0;
            int newMarkedIndex = 0;

            if (this.markedItem != null) {
                markedIndex = this.parentItem.getChildren().indexOf(this.markedItem);
                newMarkedIndex = JoMath.alwaysPosMod(markedIndex + amount, this.parentItem.getChildren().size());
            }

            //System.out.println(" oldMarked Index: " + markedIndex + " ");


            this.markedItem = this.parentItem.getChildren().get(newMarkedIndex);
            int newPage = newMarkedIndex / this.pageSize;
            if (newPage != this.currentPage) {
                goToPage(newPage);
            }
        }
    }

    public void cursorForward() {
        lastActivatedItem = null;
        if (this.markedItem != null) {
            markedItem.onActivate();
            if (markedItem.getChildCount() > 0) {
                this.parentItem = markedItem;
                this.markedItem = null;
                this.currentPage = 0;
               // System.out.println("this.parentItem: " + this.parentItem + "  this.markedItem: " + this.markedItem + " ");
            } else {

                lastActivatedItem = markedItem;
            }
        }
    }

    public void cursorBackward() {

        //System.out.println(" cursor backward");
        
        if(this.markedItem!=null){
        this.markedItem.onDeactivate();
        }
        lastActivatedItem = null;
        if (this.parentItem.getParent() != null) {
           // System.out.println("this.parentItem.getParent(): " + this.parentItem.getParent());
            this.parentItem = this.parentItem.getParent();
        }

        this.markedItem = null;
        this.currentPage = 0;
    }

    public void goToPage(int page) {
        if(this.markedItem!=null){
        this.markedItem.onDeactivate();
        }
        int minItemsForPage = page * this.pageSize + 1;
        if (minItemsForPage <= this.parentItem.getChildCount()) {

            this.currentPage = page;
        } else {

            throw new UnsupportedOperationException("Cant go to Page " + page + " min Items needed: " + minItemsForPage + " current Items: " + this.parentItem.getChildCount());
        }
    }

    public String getMenuTxt() {

        String menuTextString = "--- [" + this.parentItem.toString()+ "]: ---";


        for (int childIndex = this.pageSize * this.currentPage; childIndex < this.pageSize * (this.currentPage + 1) && childIndex < this.parentItem.getChildCount(); childIndex++) {
            menuTextString += "\n";

            SimpleMenuItem menuItem = this.parentItem.getChildren().get(childIndex);
            if (menuItem.getChildCount() > 0) {
                menuTextString += "...";
            }
            if (menuItem == this.markedItem) {
                if (menuItem == this.lastActivatedItem) {
                    menuTextString += "->";
                }
                menuTextString += "[" + menuItem.toString()+ "]";
                
            } else {
                menuTextString +=  menuItem.toString();
            }

            


        }

        menuTextString += "\n" + "Page " + (this.currentPage + 1) + " of " + (int) (Math.ceil(this.parentItem.getChildCount() / (float) this.pageSize));

        return menuTextString;
    }

    public void printMenu() {

        System.out.println(getMenuTxt());
    }

    

    
}
