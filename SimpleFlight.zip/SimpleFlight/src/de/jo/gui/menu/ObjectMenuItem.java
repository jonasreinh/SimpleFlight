/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu;

import de.jo.gui.menu.item.SimpleMenuItem;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author jonas.reinhardt
 */
public class ObjectMenuItem<T> extends SimpleMenuItem {

    private static Map<Class, MenuItemGenerator> generatorMap = new HashMap<>();
    private T object;

    public ObjectMenuItem(String name, T object) {
        super(name);
        this.object = object;
    }

    public static <T> T findParentObjectForClass(ObjectMenuItem item, Class<T> parentClass) {


        ObjectMenuItem menItem = findParentMenuItemForClass(item, parentClass);
        if (menItem != null) {
            return (T) menItem.object;
        } else {
            return null;
        }
    }

    public static <T> ObjectMenuItem findParentMenuItemForClass(ObjectMenuItem item, Class<T> parentClass) {


        //SimpleMenuItem item = this.parent;
        // System.out.println("search for "+parentClass.getName());
        while (item != null) {
            //System.out.println(" item: "+item+" object: "+item.object);//.object.getClass()
            if (item.object != null && parentClass.isAssignableFrom(item.object.getClass())) {
                return item;
            }
            if (item.parent != null && item.parent instanceof ObjectMenuItem) {

                item = (ObjectMenuItem) item.parent;
            } else {
                item = null;
            }

        }


        return null;
    }

    public T getObject() {
        return object;
    }

    public void setObject(T object) {
        this.object = object;
    }

    public static SimpleMenuItem generateFromObject(SimpleMenuItem parent, Object o) {

        if (o instanceof SimpleMenuItem) {
            return (SimpleMenuItem) o;
        } else {
            return generateFromMenuitemGenerator(getMenuItemGenerator(o.getClass()), parent, o);
        }
    }

    public static MenuItemGenerator getMenuItemGenerator(Class itemClass) {
        MenuItemGenerator generator = null;

        Class currItemClass = itemClass;
        while (currItemClass != Object.class) {

            

            generator = generatorMap.get(currItemClass);
            // System.out.println("Serching for ItemGenerator<"+currItemClass+">: "+generator);    
            if (generator != null) {
                return generator;
            } else {
                currItemClass = currItemClass.getSuperclass();
            }
        }


        throw new UnsupportedOperationException("No Generator for '" + itemClass + "' ");
    }

    private static <T> ObjectMenuItem<T> generateFromMenuitemGenerator(MenuItemGenerator<T> menuItemGenerator, SimpleMenuItem parent, T object) {

        ObjectMenuItem<T> item = new ObjectMenuItem(menuItemGenerator.getName(object), object);
        item.setParent(parent);
        //item.setObject(object);

        List<Object> children = menuItemGenerator.getChildren(item, object);

        for (Object childObject : children) {
            item.addChild(generateFromObject(item, childObject));
        }

        return item;
    }

    public static void addMenuItemGenerator(MenuItemGenerator menuItemGenerator) {
        generatorMap.put(menuItemGenerator.getForClass(), menuItemGenerator);
    }

    public static abstract class MenuItemGenerator<T> {

        private final Class<T> forClass;
        //private String name;

        public MenuItemGenerator(Class<T> forClass) {
            this.forClass = forClass;

        }

        public Class<T> getForClass() {
            return forClass;
        }

        public abstract String getName(T object);

        public abstract List<Object> getChildren(SimpleMenuItem parent, T object);
    }
}
