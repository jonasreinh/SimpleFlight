/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.value;

import de.jo.gui.menu.SimpleMenu;
import de.jo.gui.menu.item.SimpleMenuItem;
import com.jme3.math.Vector3f;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;


/**
 *
 * @author jonas.reinhardt
 */
public abstract class Vector3fMenuItem extends SimpleMenuItem{
private DecimalFormat format = new DecimalFormat( "0.000" );
{
    format.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
//format.applyLocalizedPattern("en_US");
}
private SimpleMenu menu;
    
    
    public Vector3fMenuItem(String name, SimpleMenu menu) {
        super(name);
        this.menu = menu;
    }
    
    
  public abstract Vector3f getValue();
  
  
  public abstract void setValueIntern(Vector3f value);
  
  public void setValue(Vector3f value){
      
  setValueIntern(value);
  
  //this.menu.printMenu();
      
  }

     @Override
    public String toString() {
         Vector3f vec = getValue();
         
        return name +( vec != null ? ": ("+format.format(vec.x)+","+format.format(vec.y)+","+format.format(vec.z)+")" : "null");
    }
}
