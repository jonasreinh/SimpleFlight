/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.input;

import de.jo.gui.menu.item.SimpleMenuItem;
import de.jo.input.SimpleInputReceiverManager;

/**
 *
 * @author User
 */
public abstract class SimpleInputItem extends SimpleMenuItem implements SimpleInputReceiverManager.SimpleInputReceiver{

    public SimpleInputItem(String name) {
        super(name);
    }

    @Override
    public void onActivate() {
        SimpleInputReceiverManager.setActiveReceiver(this);
    }
    
    
    
    @Override
    public void onDeactivate() {
        if(SimpleInputReceiverManager.getActiveReceiver() == this){
            SimpleInputReceiverManager.setActiveReceiver(null);
        }
        
    }
}
