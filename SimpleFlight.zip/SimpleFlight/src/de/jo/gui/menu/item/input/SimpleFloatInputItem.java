/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.input;

import de.jo.input.SimpleInputReceiverManager;

/**
 *
 * @author User
 */
public abstract class SimpleFloatInputItem extends SimpleInputItem {

    private float changeAmount = 1;
    
    private float minVal;
    private float maxVal;
    
    private boolean useMinVal = false;
    private boolean useMaxVal = false;

    public SimpleFloatInputItem(String name) {
        super(name);
    }

    public SimpleFloatInputItem(String name,float changeAmount) {
        super(name);
        this.changeAmount = changeAmount;
    }
    
    
    protected abstract float getValue();

    protected abstract void setValue(float value);

    @Override
    public void onValueAction(SimpleInputReceiverManager.SimpleInputReceiver.InputValue inputValue, float timeVal, float axisVal, boolean repeating) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //System.out.println("On Value Action input: "+inputValue+" timeVal: "+timeVal+" axisVal: "+axisVal+" repeating: "+repeating);
        float oldVal = getValue();
        float newVal = oldVal;
        switch (inputValue) {
            case valueMult: {
                changeAmount *= 2;
            }
            break;
            case valueDiv: {
                changeAmount *= 0.5f;
            }
            break;
            case valueInc: {
                newVal = oldVal +changeAmount;
            }
            break;
            case valueDec: {
                newVal = oldVal -changeAmount;
            }
            break;

        }
        
        if(newVal != oldVal && (!useMinVal||(newVal>=minVal)) && (!useMaxVal||(newVal<=maxVal))){
            setValue(newVal);         
            }
    }
    
    @Override
            public String toString() {
                return super.name +": "+getValue()+" (changeAmount: "+changeAmount+")"; //To change body of generated methods, choose Tools | Templates.
            }

    public float getMinVal() {
        return minVal;
    }

    public void setMinVal(float minVal) {
        this.minVal = minVal;
    }

    public float getMaxVal() {
        return maxVal;
    }

    public void setMaxVal(float maxVal) {
        this.maxVal = maxVal;
    }

    public boolean isUseMinVal() {
        return useMinVal;
    }

    public void setUseMinVal(boolean useMinVal) {
        this.useMinVal = useMinVal;
    }

    public boolean isUseMaxVal() {
        return useMaxVal;
    }

    public void setUseMaxVal(boolean useMaxVal) {
        this.useMaxVal = useMaxVal;
    }



}
