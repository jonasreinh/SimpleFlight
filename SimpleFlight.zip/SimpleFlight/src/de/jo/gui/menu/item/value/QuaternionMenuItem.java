/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.value;

import com.jme3.math.Quaternion;
import de.jo.gui.menu.SimpleMenu;
import de.jo.gui.menu.item.SimpleMenuItem;
import com.jme3.math.Vector3f;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;


/**
 *
 * @author jonas.reinhardt
 */


public abstract class QuaternionMenuItem extends SimpleMenuItem{
private DecimalFormat format = new DecimalFormat( "0.000" );
{
    format.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
//format.applyLocalizedPattern("en_US");
}
private SimpleMenu menu;

    public DecimalFormat getFormat() {
        return format;
    }
    
    
    public QuaternionMenuItem(String name, SimpleMenu menu) {
        super(name);
        this.menu = menu;
    }
    
    
  public abstract Quaternion getValue();
  
  
  public abstract void setValueIntern(Quaternion value);
  
  public void setValue(Quaternion value){
      
  setValueIntern(value);
  
  //this.menu.printMenu();
      
  }

     @Override
    public String toString() {
         Quaternion quat = getValue();

        return name +( quat != null ? ": ("+format.format(quat.getW())+","+format.format(quat.getX())+","+format.format(quat.getY())+","+format.format(quat.getZ())+")" : "null");
    }
}
