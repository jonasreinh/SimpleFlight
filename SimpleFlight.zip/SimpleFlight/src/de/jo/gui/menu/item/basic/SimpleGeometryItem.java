/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.basic;

import com.jme3.scene.Geometry;
import de.jo.gui.menu.item.SimpleMenuItem;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 *
 * @author User
 */
public class SimpleGeometryItem extends SimpleMenuItem {

    private Geometry geometry;
    private DecimalFormat format = new DecimalFormat("0.000");

    {
        format.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
    }
    protected float manipulationMult = 0.125f;
    
    protected float moveSpeed = 5;

    public SimpleGeometryItem(String name, Geometry geometryIn) {
        super(name);
        this.geometry = geometryIn;
        
       this.addChild(new SimpleMaterialItem("Material: ",geometry.getMaterial()));
    }
    
    
    
    
}
