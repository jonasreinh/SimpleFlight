/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jonas.reinhardt
 */
public class SimpleMenuItem {

    
    protected String name;
   
    
    protected SimpleMenuItem parent;
    protected List<SimpleMenuItem> children = new ArrayList<SimpleMenuItem>();

    public SimpleMenuItem(String name) {
        this.name = name;
    }

    
    public void addChild(SimpleMenuItem simpleMenuItem) {

        this.children.add(simpleMenuItem);
        simpleMenuItem.parent = this;


    }

    public int getChildCount() {
        /*
         * if(this.children!=null){
         return this.children.size();  
         }else{
         return 0;
         }
         */
        return this.getChildren().size();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SimpleMenuItem getParent() {
        return parent;
    }

    public void setParent(SimpleMenuItem parent) {
        this.parent = parent;
    }

    public List<SimpleMenuItem> getChildren() {
        return children;
    }
    /*
     public void setChildren(List<SimpleMenuItem> children) {
     this.children = children;
     }*/

    @Override
    public String toString() {
        return name;
    }

    public void onActivate() {
    }

    public void onDeactivate() {
    }
    
    
   
}
