/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui.menu.item.value;

import de.jo.gui.menu.SimpleMenu;
import de.jo.input.SimpleInputReceiverManager;
import de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver;
import static de.jo.input.SimpleInputReceiverManager.SimpleInputReceiver.InputValue.valueInc;

/**
 *
 * @author jonas.reinhardt
 */
public abstract class NumberManipulatorItem<T extends Number> extends ValueMenuItem<T> implements SimpleInputReceiver {

    protected T stepSize;

    public NumberManipulatorItem(String name, SimpleMenu menu, T stepSize) {
        super(name, menu);
        this.stepSize = stepSize;
    }

    public abstract void increase();

    public abstract void decrease();

    @Override
    public void onActivate() {
        super.onActivate(); //To change body of generated methods, choose Tools | Templates.
       SimpleInputReceiverManager.setActiveReceiver(this);
    }

    @Override
    public void onDeactivate() {
        super.onDeactivate(); //To change body of generated methods, choose Tools | Templates.
        if (SimpleInputReceiverManager.getActiveReceiver() == this) {
            SimpleInputReceiverManager.setActiveReceiver(null);
        }
    }

    public void onValueAction(InputValue inputValue, float timeVal, float axisVal, boolean repeating) {

        switch (inputValue) {

            case valueInc:
                increase();
                break;
                
            case valueDec:
                decrease();
                break;
        }

    }
    /*public static NumberManipulatorItem getActiveItem() {
     return activeItem;
     }*/
}
