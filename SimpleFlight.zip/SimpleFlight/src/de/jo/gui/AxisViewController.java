/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.gui;

import com.jme3.app.SimpleApplication;
import com.jme3.asset.AssetManager;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Mesh;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.Control;
import de.jo.flight.steering.FlightSteering;
import de.jo.gui.flightcursor.FlightGui;
import de.jo.mesh.dynamic.DynamicGeometry;
import mygame.ChaseCamera;
import mygame.FlyApp;
import mygame.SphericData;

/**
 *
 * @author jonas.reinhardt
 */
public class AxisViewController extends Node implements Control {

    private ViewPort viewPort;
    private AssetManager assetManager;
    private Vector3f midPos = new Vector3f();
    private FlightGui flightCursor;
    private SimpleApplication main;
    private Vector3f axisDisplayPosition = new Vector3f(0.8f, -0.8f, 4);
    private DynamicGeometry axisDisplay;
    private DynamicGeometry zVecDisplay;
    private SphericData sphericData;
    private Quaternion camInverse = new Quaternion();
    
    //private Node camNode = new Node("Cam Node");
    //private FlightSteering flightSteering;
    //private Vector2f mouseMovedStore = new Vector2f();
    
    
    private ChaseCamera chaseCamera;
            
    public AxisViewController(){
        
    }
    
    public void showDebug(boolean show){
        if(show){
        chaseCamera.getCamNode().attachChild(sphericData.getDataDisplay());
        }else{
            chaseCamera.getCamNode().detachChild(sphericData.getDataDisplay());
        }
    }
    
    public void showAxisDisplay(boolean show){
        if(show){
        chaseCamera.getCamNode().attachChild(axisDisplay);
        }else{
            chaseCamera.getCamNode().detachChild(axisDisplay);
        }
    }
    
     public void showzVecDisplay(boolean show){
        if(show){
        chaseCamera.getCamNode().attachChild(zVecDisplay);
        }else{
            chaseCamera.getCamNode().detachChild(zVecDisplay);
        }
    }
    
    
    
    public void init(SimpleApplication main, ChaseCamera chaseCamera) {
        
        this.main = main;
        this.viewPort = main.getViewPort();
        this.assetManager = main.getAssetManager();
        this.chaseCamera = chaseCamera;
        
        this.updateMidPos();
        
        System.out.println("ViewPort W: " + getW() + " H: " + getH());

       
        sphericData = new SphericData();
        
        sphericData.init(main.getAssetManager(),new Material(assetManager, "MatDefs/InfUnsh.j3md"));
        
        sphericData.getDataDisplay().getMaterial().setFloat("pointSize", 3);
        
       // main.getRootNode().attachChild();
        
       
        sphericData.getDataDisplay().setLocalTranslation(axisDisplayPosition);
        //main.getChaseCam().getCamNode().updateGeometricState();
        
        this.flightCursor = new FlightGui();
        
        this.flightCursor.init(assetManager);
        this.flightCursor .setLocalTranslation(midPos.clone());
        
         main.getRootNode().addControl(this);
       
       // this.flightCursor.init(assetManager, getW(), getH());
        
      //  this.flightCursor.getGeometry().setLocalTranslation(middlePos);
        
       this.attachChild(flightCursor);
       
       //flightSteering = new FlightSteering();
      
       
       // main.getRootNode().attachChild(camNode);
        
        axisDisplay = new DynamicGeometry();
        axisDisplay.init(assetManager, new Material(assetManager, "MatDefs/InfUnsh.j3md"));
        axisDisplay.getMaterial().setColor("Color", ColorRGBA.White);    
        axisDisplay.getDynamicMesh().setUseColor(true);
        axisDisplay.getDynamicMesh().setMode(Mesh.Mode.Lines);
        axisDisplay.getDynamicMesh().setLineWidth(2);
        axisDisplay.getDynamicMesh().addIndexdata(0, 1, 2, 3, 4, 5);
        axisDisplay.getDynamicMesh().addVertexes(6);
        axisDisplay.getDynamicMesh().addColors(6);
        axisDisplay.getDynamicMesh().updateMesh();
        axisDisplay.getDynamicMesh().setVertexPositionData(1, new Vector3f(1, 0, 0));
        axisDisplay.getDynamicMesh().setVertexPositionData(3, new Vector3f(0, 1, 0));
        axisDisplay.getDynamicMesh().setVertexPositionData(5, new Vector3f(0, 0, 1));
        axisDisplay.getDynamicMesh().setVertexColorData(0,  ColorRGBA.Red, ColorRGBA.Red, ColorRGBA.Green,ColorRGBA.Green,ColorRGBA.Blue,ColorRGBA.Blue);
        axisDisplay.getDynamicMesh().applyBuffers();
        axisDisplay.getMaterial().setBoolean("VertexColor", true);
        axisDisplay.updateModelBound();
        axisDisplay.updateGeometricState();
        axisDisplay.setLocalTranslation(axisDisplayPosition);
       
            
       
        zVecDisplay = new DynamicGeometry();
        zVecDisplay.init(assetManager,  new Material(assetManager, "MatDefs/InfUnsh.j3md"));
        zVecDisplay.getMaterial().setColor("Color", ColorRGBA.Red);
        zVecDisplay.getMaterial().setFloat("pointSize", 4);  
        zVecDisplay.getDynamicMesh().setMode(Mesh.Mode.Points);
        zVecDisplay.getDynamicMesh().addIndexdata(0);
        zVecDisplay.getDynamicMesh().addVertexes(1);
        zVecDisplay.getDynamicMesh().updateMesh();
        zVecDisplay.getDynamicMesh().setVertexPositionData(0, new Vector3f(0, 0, 1));
        zVecDisplay.getDynamicMesh().applyBuffers();
        zVecDisplay.setLocalTranslation(axisDisplayPosition);
        zVecDisplay.updateModelBound();
        zVecDisplay.updateGeometricState();
      //chaseCamera.getCamNode().attachChild(zVecDisplay);
       
    }

    public FlightGui getFlightCursor() {
        return flightCursor;
    }

    private void updateMidPos(){
        
        this.midPos.set(getW() * 0.5f, getH() * 0.5f, 0);
    }
    
    public void update(float tpf){
        
        //camNode.setLocalTranslation(main.getCamera().getLocation());
        //camNode.setLocalRotation(main.getCamera().getRotation());
        Quaternion camRot =  main.getCamera().getRotation();
        camInverse = camRot.inverse();
        axisDisplay.setLocalRotation(camInverse);
        //zVecDisplay.setLocalRotation(camInverse);
        
        Quaternion relTargetRot = camInverse.mult(chaseCamera.getTarget().getWorldRotation());
        
        sphericData.getDataDisplay().setLocalRotation(relTargetRot);
        zVecDisplay.setLocalRotation(camInverse);//getDynamicMesh().setVertexPositionData(0, chaseCamera.getTarget().getWorldRotation().inverse().mult(Vector3f.UNIT_Z));
        zVecDisplay.getDynamicMesh().applyBuffers();
       // zVecDisplay.setLocalRotation(camInverse.mult());
         Vector3f displayPos = main.getCamera().getLocation().add( main.getCamera().getRotation().mult(axisDisplayPosition));
   // axisDisplay.setLocalTranslation( displayPos);
     //  zVecDisplay.setLocalTranslation( displayPos);
       //zVecDisplay.setLocalRotation(ship.getWorldRotation());
      // sphericData.updatePosition(displayPos);
       // flightCursor.update();
   // flightSteering.update(System.currentTimeMillis());
    
        
   /* if(mouseMovedStore.x!=0 || mouseMovedStore.y!=0){
        //System.out.println("MouseMoved ("+mouseMovedStore.x+","+mouseMovedStore.y+")");
    Vector2f mouseMoved = mouseMovedStore.clone();
    mouseMovedStore.x = 0;
    mouseMovedStore.y = 0;    
    
    flightCursor.onCursorMoved(mouseMoved.x, mouseMoved.y);
    
    }   */ 
        

    
        
    }
    
    
    
    public AssetManager getAssetManager() {
        return assetManager;
    }

    public int getH() {

        return viewPort.getCamera().getHeight();
    }

    public int getW() {

        return viewPort.getCamera().getWidth();
    }

    public Vector3f getMidPos() {
        return midPos;
    }

    public Control cloneForSpatial(Spatial spatial) {
     return null;  // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setSpatial(Spatial spatial) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void render(RenderManager rm, ViewPort vp) {
       /// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
