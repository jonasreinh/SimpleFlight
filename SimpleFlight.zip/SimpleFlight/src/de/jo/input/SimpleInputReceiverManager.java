/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

import com.jme3.input.KeyInput;

/**
 *
 * @author jonas.reinhardt
 */
public class SimpleInputReceiverManager {

    private static SimpleInputReceiver activeReceiver;

    public static SimpleInputReceiver getActiveReceiver() {
        return activeReceiver;
    }

    public static void setActiveReceiver(SimpleInputReceiver activeReceiver) {
        SimpleInputReceiverManager.activeReceiver = activeReceiver;
    }

    public static void init() {
        InputController inputController = InputController.getInstance();
        
        
        
        InputAction upVal = new InputAction("Value up", true) {
            @Override
            public void onAction(float timeVal, float axisVal) {

                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueUp, timeVal,axisVal,false);
                }
            }
        };
        upVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_NUMPAD8));
        inputController.addInputAction(upVal);
        
        InputAction downVal = new InputAction("Value down", true) {
            @Override
            public void onAction(float timeVal, float axisVal) {

                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueDown, timeVal,axisVal,false);
                }
            }
        };
        downVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_NUMPAD2));
        inputController.addInputAction(downVal);
        
        
        InputAction forwardVal = new InputAction("Value forward", true) {
            @Override
            public void onAction(float timeVal, float axisVal) {

                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueForward, timeVal,axisVal,false);
                }
            }
        };
        forwardVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_NUMPAD7));
        inputController.addInputAction(forwardVal);
        
        InputAction backwardVal = new InputAction("Value backward", true) {
            @Override
            public void onAction(float timeVal, float axisVal) {

                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueBackward, timeVal,axisVal,false);
                }
            }
        };
        backwardVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_NUMPAD1));
        inputController.addInputAction(backwardVal);
        
        InputAction rightVal = new InputAction("Value right", true) {
            @Override
            public void onAction(float timeVal, float axisVal) {

                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueRight, timeVal,axisVal,false);
                }
            }
        };
        rightVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_NUMPAD6));
        inputController.addInputAction(rightVal);
        
        InputAction leftVal = new InputAction("Value left", true) {
            @Override
            public void onAction(float timeVal, float axisVal) {

                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueLeft, timeVal,axisVal,false);
                }
            }
        };
        leftVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_NUMPAD4));
        inputController.addInputAction(leftVal);
        
        
        InputAction incVal = new InputAction("increase Number Value", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {

                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueInc, timeVal,axisVal,false);
                }
            }
        };
        incVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_ADD));
        inputController.addInputAction(incVal);


        InputAction decVal = new InputAction("decrease Number Value", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {
                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueDec, timeVal,axisVal,false);
                }
            }
        };
        decVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_SUBTRACT));
        inputController.addInputAction(decVal);
        
        InputAction multVal = new InputAction("multiply Number Value", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {
                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueMult, timeVal,axisVal,false);
                }
            }
        };
        multVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_MULTIPLY));
        inputController.addInputAction(multVal);

        
        
        InputAction divVal = new InputAction("divide Number Value", false) {
            @Override
            public void onAction(float timeVal, float axisVal) {
                if (activeReceiver != null) {
                    activeReceiver.onValueAction(SimpleInputReceiver.InputValue.valueDiv, timeVal,axisVal,false);
                }
            }
        };
        divVal.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_DIVIDE));
        inputController.addInputAction(divVal);

    }

    public static interface SimpleInputReceiver {

        public enum InputValue {

            valueUp, valueDown, valueRight, valueLeft, valueForward, valueBackward, valueMult, valueDiv, valueInc, valueDec
        }

        public void onValueAction(InputValue inputValue, float timeVal, float axisVal, boolean repeating);
    }
}
