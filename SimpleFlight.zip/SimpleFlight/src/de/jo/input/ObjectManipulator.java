/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

/**
 *
 * @author jonas.reinhardt
 */
public interface ObjectManipulator <T> {
 
    
public T getObject();

public void setObject(T object);


public void setValue(int id, float value);


public void setActivated(boolean activated);

public boolean isActivated();
    
}
