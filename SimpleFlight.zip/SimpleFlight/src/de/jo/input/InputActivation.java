/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.input;

import com.jme3.input.KeyInput;
import com.jme3.input.RawInputListener;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class InputActivation {

    public enum InputType {
        BUTTON, AXIS
    };
    private static Map<Integer, String> keyStrings = new HashMap<>();

    static {

        Field[] fields = KeyInput.class.getFields();

        try {
            for (int i = 0; i < fields.length; i++) {
                String inputCodeString = fields[i].getName().substring(4);
                int inputCode = (int) fields[i].get(null);

                keyStrings.put(inputCode, inputCodeString);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public enum InputSource {
        KEYBOARD, MOUSE
    };
    
    private InputType inputType;
    private InputSource inputSource;
    private int inputActivationCode;
    private boolean pressed;

    public InputActivation(boolean pressed, InputType inputType, InputSource inputSource, int inputActivationCode) {
        this.inputType = inputType;
        this.inputSource = inputSource;
        this.inputActivationCode = inputActivationCode;
        this.pressed = pressed;
    }

    public boolean isPressed() {
        return pressed;
    }

    public InputType getInputType() {
        return inputType;
    }

    public void setInputType(InputType inputType) {
        this.inputType = inputType;
    }

    public InputSource getInputSource() {
        return inputSource;
    }

    public void setInputSource(InputSource inputSource) {
        this.inputSource = inputSource;
    }

    public void setPressed(boolean pressed) {
        this.pressed = pressed;
    }

    public int getInputActivationCode() {
        return inputActivationCode;
    }

    public void setInputActivationCode(int inputActivationCode) {
        this.inputActivationCode = inputActivationCode;
    }

    public String getInputCodeString(){
        
        return getInputName(inputSource, inputActivationCode);
    }
    
    @Override
    public String toString() {
        return "InputActivation{" + "inputType=" + inputType + ", inputSource=" + inputSource + ", [" + inputActivationCode + "], press:" + pressed + '}';
    }

    public static String getInputName(InputSource inputSource, int code) {

        if (inputSource == InputSource.KEYBOARD) {
            return keyStrings.get(code);
        } else if (inputSource == InputSource.KEYBOARD) {
        }



        return null;
    }
}