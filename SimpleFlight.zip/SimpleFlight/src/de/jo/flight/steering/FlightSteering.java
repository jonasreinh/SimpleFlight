/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jo.flight.steering;

import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import de.jo.input.InputAction;
import de.jo.input.InputActivation;
import de.jo.input.InputController;

/**
 *
 * @author jonas.reinhardt
 */
public class FlightSteering {

    public SteeringAxis pitchAxis;
    public SteeringAxis yawAxis;
    public SteeringAxis rollAxis;
    public SteeringAxis forwardThrottleAxis;
    private SteeringAxis[] axis;

    public FlightSteering() {

        this.pitchAxis = new SteeringAxis(SteeringAxis.AxisMode.MoveToTarget, -100, +100, 0);
        this.yawAxis = new SteeringAxis(SteeringAxis.AxisMode.MoveToTarget, -100, +100, 0);
        this.rollAxis = new SteeringAxis(SteeringAxis.AxisMode.MoveToTarget, -100, +100, 0);
        this.yawAxis.setDirectionBehaviour(SteeringAxis.DirectionBehaviour.FitToSign);
        this.pitchAxis.setDirectionBehaviour(SteeringAxis.DirectionBehaviour.FitToSign);
        this.rollAxis.setDirectionBehaviour(SteeringAxis.DirectionBehaviour.FitToSign);
        this.forwardThrottleAxis = new SteeringAxis(SteeringAxis.AxisMode.Static, 0, 100);

        axis = new SteeringAxis[]{pitchAxis, yawAxis, rollAxis, forwardThrottleAxis};
        InputAction roll = new InputAction("roll mouse", false) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                rollAxis.onInput(axisVal);
            }
        };
        roll.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.AXIS, InputActivation.InputSource.MOUSE, MouseInput.AXIS_X));
        roll.getRequiredActivations().add(new InputActivation(false, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_LMENU));


        InputAction rollInc = new InputAction("roll increase", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                rollAxis.onInput(-value*60);
            }
        };
        rollInc.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_A));
        
        
        InputAction rollDec = new InputAction("roll decrease", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                rollAxis.onInput(value*60);
            }
        };
        rollDec.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_D));
        
        
        InputAction pitch = new InputAction("pitch mouse", false) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                pitchAxis.onInput(axisVal);
            }
        };
        
        pitch.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.AXIS, InputActivation.InputSource.MOUSE, MouseInput.AXIS_Y));
        pitch.getRequiredActivations().add(new InputActivation(false, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_LMENU));


        
        InputAction pitchInc = new InputAction("pitch increase", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                pitchAxis.onInput(-value*60);
            }
        };
        pitchInc.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_S));
        
        
        InputAction pitchDec = new InputAction("pitch decrease", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                pitchAxis.onInput(value*60);
            }
        };
        pitchDec.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_W));
        
        
         InputAction yawInc = new InputAction("pitch increase", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                yawAxis.onInput(-value*60);
            }
        };
        yawInc.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_Q));
        
        
        InputAction yawDec = new InputAction("pitch decrease", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                yawAxis.onInput(value*60);
            }
        };
        yawDec.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_E));
        


        //InputController.getInstance().addInputAction(roll);
        InputController.getInstance().addInputAction(rollInc);
        InputController.getInstance().addInputAction(rollDec);
        
       // InputController.getInstance().addInputAction(pitch);
        InputController.getInstance().addInputAction(pitchInc);
        InputController.getInstance().addInputAction(pitchDec);

        InputController.getInstance().addInputAction(yawInc);
        InputController.getInstance().addInputAction(yawDec);
        
        
        InputAction throttleInc = new InputAction("throttle increase", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("forwardThrottleAxis x val: "+value);
                forwardThrottleAxis.onInput(value*100);
                
            }
        };
        throttleInc.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_LSHIFT));
        
        InputAction throttleDec = new InputAction("throttle decrease", true) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("forwardThrottleAxis x val: "+value);
                forwardThrottleAxis.onInput(value*-100);
                
            }
        };
        throttleDec.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_LCONTROL));

        InputController.getInstance().addInputAction(throttleDec);
        InputController.getInstance().addInputAction(throttleInc);
    }

    public void update(long time) {

        for (SteeringAxis steeringAxis : axis) {
            steeringAxis.update(time);
        }

    }
}
