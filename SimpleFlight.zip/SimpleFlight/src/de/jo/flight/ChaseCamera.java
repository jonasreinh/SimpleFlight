/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.math.FastMath;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.Control;
import de.jo.input.InputAction;
import de.jo.input.InputActivation;
import de.jo.input.InputController;
import java.io.IOException;

/**
 * A camera that follows a spatial and can turn around it by dragging the mouse
 * @author nehon
 */
public class ChaseCamera implements  Control {

    protected Spatial target = null;
    
    protected Camera cam = null;
    
    private Quaternion quat = new Quaternion();
    
    private  float minDist = 28.0f;
    
    private Vector3f camRelativePos = new Vector3f(0,0,-35);
   
     private Vector3f targetLastPos = new Vector3f(0,0,0);
     
     private Node camNode = new Node();
     
    
    public ChaseCamera(Camera cam, final Spatial target) {
        this(cam);
        target.addControl(this);
        
        InputAction rotateX = new InputAction("RotateX", false) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                rotate(new Vector3f(0,0.01f*axisVal,0));
            }
        };
        //rotateX.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_C));
        rotateX.getRequiredActivations().add(new InputActivation(false, InputActivation.InputType.BUTTON, InputActivation.InputSource.MOUSE, MouseInput.BUTTON_RIGHT));
        rotateX.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.AXIS, InputActivation.InputSource.MOUSE, MouseInput.AXIS_X));
        
        
        InputAction rotateY = new InputAction("RotateY", false) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                rotate(new Vector3f(0.007f*axisVal,0,0));
            }
        };
        rotateY.getRequiredActivations().add(new InputActivation(false, InputActivation.InputType.BUTTON, InputActivation.InputSource.MOUSE, MouseInput.BUTTON_RIGHT));
        rotateY.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.AXIS, InputActivation.InputSource.MOUSE, MouseInput.AXIS_Y));
        
        
        InputController.getInstance().addInputAction(rotateX);
        InputController.getInstance().addInputAction(rotateY);
        
        
         
        InputAction zoom = new InputAction("Zoom", false) {
            @Override
            public void onAction(float value, float axisVal) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("mouse x val: "+axisVal);
                zoom(-0.01f*axisVal);
            }
        };
        zoom.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.MOUSE, MouseInput.BUTTON_RIGHT));
        zoom.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.AXIS, InputActivation.InputSource.MOUSE, MouseInput.AXIS_Y));
        
        
        InputController.getInstance().addInputAction(zoom);
        
    }
    
    
    public void zoom(float val){

     Vector3f newPos =  camRelativePos.mult(1.0f+val);
     float dist = newPos.length();
     
    
     float maxDist = 20000.0f;
     
     if(dist < minDist){
         newPos.normalizeLocal().multLocal(minDist);
     }else if(dist > maxDist){
         newPos.normalizeLocal().multLocal(maxDist);
     }
     camRelativePos = newPos;
    }
    
    public void rotate(Vector3f rotation){
     //Vector3f rot = cam.getRotation().mult(rotation);
     float yValAbs = FastMath.abs(camRelativePos.normalize().y);
     rotation.x = rotation.x*(1-(yValAbs*yValAbs)); 
     
     quat.lookAt(camRelativePos.mult(-1), new Vector3f(0,1,0));
     rotation = quat.mult(rotation);
     
    quat = quat.fromAngles(new float[]{rotation.x,rotation.y,rotation.z});
    
      //cam.setRotation(quat.mult(cam.getRotation()));
      //cam.setRotation(quat);
    camRelativePos = quat.mult(camRelativePos);
    }

    public ChaseCamera(Camera cam) {
        this.cam = cam;
        
    }

    public Spatial getTarget() {
        return target;
    }


    /**
     * Sets the spacial for the camera control, should only be used internally
     * @param spatial
     */
    public void setSpatial(Spatial spatial) {
        target = spatial;
        
        targetLastPos = target.getWorldTranslation();

        cam.setLocation((target.getLocalRotation().mult(camRelativePos)).add(targetLastPos));
        
      
    }

    public Node getCamNode() {
        return camNode;
    }

    /**
     * update the camera control, should only be used internally
     * @param tpf
     */
    public void update(float tpf) {
     
      targetLastPos = new Vector3f(target.getWorldTranslation());  
        
       cam.setLocation((target.getWorldRotation().mult(camRelativePos)).add(targetLastPos));
        cam.lookAt(targetLastPos, target.getWorldRotation().getRotationColumn(1));
      
       camNode.setLocalTranslation(cam.getLocation());
       camNode.setLocalRotation(cam.getRotation());
    }

    /**
     * renders the camera control, should only be used internally
     * @param rm
     * @param vp
     */
    public void render(RenderManager rm, ViewPort vp) {
        //nothing to render
    }

    public Control cloneForSpatial(Spatial spatial) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void write(JmeExporter ex) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void read(JmeImporter im) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
