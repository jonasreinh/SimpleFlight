/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.asset.AssetManager;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.control.VehicleControl;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.shape.Box;
import com.jme3.bullet.collision.shapes.BoxCollisionShape;
import com.jme3.input.KeyInput;
import com.jme3.math.Vector3f;
import com.jme3.scene.shape.Sphere;
import com.jme3.texture.Texture;
import com.jme3.texture.TextureCubeMap;
import de.jo.flight.steering.FlightControl;
import de.jo.input.InputAction;
import de.jo.input.InputActivation;
import de.jo.input.InputController;

import de.jo.input.InputMapping;
import de.jo.mesh.animation.MeshAnimation;

/**
 *
 * @author jonas.reinhardt
 */
public class Ship extends Node {

    private FlightControl flightControl;
    private Geometry shipGeometry;
    
    private MeshAnimation glowAnimation;
    //private FlightControl flightBehaviour = new FlightControl();
    public Ship() {


        InputAction inputAction = new InputAction("test", false) {
            @Override
            public void onAction(float value, float axisVal) {
                System.out.println(" action: " + value);



                //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };

        inputAction.getRequiredActivations().add(new InputActivation(true, InputActivation.InputType.BUTTON, InputActivation.InputSource.KEYBOARD, KeyInput.KEY_SPACE));

        InputController.getInstance().addInputAction(inputAction);

    }

    public void update(){
        
        
    }

    public FlightControl getFlightControl() {
        return flightControl;
    }
    
    
    
    public void init(AssetManager assetManager, PhysicsSpace physicsSpace) {
        //Box b = new Box(1, 1, 2);
        //shipGeometry = new Geometry("ship",new Sphere(8, 8, 4));
        //shipGeometry.setMaterial( assetManager.loadMaterial("Materials/TerrainMat.j3m"));
        shipGeometry = (Geometry) assetManager.loadModel("Models/tu-128.j3o");//new Geometry("Box", b);//
        Material planeMat = assetManager.loadMaterial("Materials/PlaneMat.j3m") ;//new Material(assetManager, "")//simpleApplication.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        Texture tex = planeMat.getTextureParam("EnvMap").getTextureValue();
        TextureCubeMap newTex = new TextureCubeMap();
        newTex.setImage(tex.getImage());
        planeMat.setTexture("EnvMap",newTex);
        
        shipGeometry.setMaterial(planeMat);
        this.attachChild(shipGeometry);
        
        Geometry windowGeometry = (Geometry) assetManager.loadModel("Models/tu-128-windows.j3o");
        Material windowMat = assetManager.loadMaterial("Materials/WindowMat.j3m") ;//new Material(assetManager, "")//simpleApplication.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        windowGeometry.setMaterial(windowMat);
        this.attachChild(windowGeometry);
        //mat.setColor("Diffuse", ColorRGBA.Gray);
        //mat.setBoolean("UseMaterialColors", true);
        

        flightControl = new FlightControl(2);



        this.addControl(flightControl);


        flightControl.setCollisionShape(new BoxCollisionShape(new Vector3f(1f, 1f, 2)));

        physicsSpace.add(this);
        physicsSpace.addTickListener(flightControl);
        flightControl.setMass(100);
        flightControl.setApplyPhysicsLocal(true);
        flightControl.setAngularDamping(0.8f);
        flightControl.setDamping(0.0f, 0.8f);
        flightControl.setFriction(0.0f);

        flightControl.setLinearSleepingThreshold(0.1f);
        
    }

    
    
    
    /* @InputMapping(repeating = true, actionName = "accelerationAction", activationInput = {de.jo.input.InputMapping.INPUTTYPE_Button,de.jo.input.InputMapping.INPUTSOURCE_Key,com.jme3.input.KeyInput.KEY_SPACE,
     })
     public void accelerate() {
        
     System.out.println("accelerating");
        
     }
     */

    public Geometry getShipGeometry() {
        return shipGeometry;
    }
}
