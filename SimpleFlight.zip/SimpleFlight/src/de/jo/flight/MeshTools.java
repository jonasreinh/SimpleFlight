/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.math.Vector3f;
import com.jme3.scene.Mesh;
import com.jme3.scene.VertexBuffer;
import java.nio.FloatBuffer;

/**
 *
 * @author User
 */
public class MeshTools {
    
    
 public static void moveVertexes(Mesh m, Vector3f vec){
     FloatBuffer posBuff = m.getFloatBuffer(VertexBuffer.Type.Position);
     
     Vector3f oldPos = new Vector3f();
     for(int i = 0; i <posBuff.limit()/3;i++){
        posBuff.position(i*3); 
        oldPos.x = posBuff.get();
        oldPos.y = posBuff.get();
        oldPos.z = posBuff.get();
        posBuff.position(i*3); 
        posBuff.put(oldPos.x+vec.x).put(oldPos.y+vec.y).put(oldPos.z+vec.z);
     }
     
 }   
    
}
